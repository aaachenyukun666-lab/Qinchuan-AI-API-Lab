/**
 * Integration tests: engine + verification against a local mock
 * OpenAI-compatible server. Every request here is a real HTTP call to a
 * localhost mock — no results are fabricated.
 *
 * Run with: npm test
 */
const test = require('node:test');
const assert = require('node:assert');
const http = require('node:http');

const engine = require('../src/js/engine.js');
const verify = require('../src/js/verify.js');
const api = require('../src/js/api.js');
const report = require('../src/js/report.js');
const statsLib = require('../src/js/core/stats.js');

const VALID_KEY = 'sk-test-valid-key-0001';

/** Start a mock OpenAI-compatible relay. Returns {server, baseUrl, hits}. */
async function startMock(options) {
  const opts = Object.assign({ status: 200, usage: true }, options);
  const hits = { chat: 0, models: 0, balance: 0 };
  const server = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      const auth = req.headers.authorization || '';
      if (auth !== 'Bearer ' + VALID_KEY) {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: 'Incorrect API key' } }));
        return;
      }
      if (req.url.endsWith('/models')) {
        hits.models++;
        if (opts.killModels) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: { message: 'no models endpoint' } }));
          return;
        }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ data: [{ id: 'model-a' }, { id: 'model-b' }, { id: 'model-a' }] }));
        return;
      }
      if (req.url.endsWith('/user/balance')) {
        hits.balance++;
        if (opts.killBalance) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: { message: 'no balance endpoint' } }));
          return;
        }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ balance_infos: [{ currency: 'CNY', total_balance: 50 }] }));
        return;
      }
      if (req.url.endsWith('/chat/completions')) {
        hits.chat++;
        const params = body ? JSON.parse(body) : {};
        if (opts.delayMs) {
          setTimeout(() => respond(params), opts.delayMs);
          return;
        }
        respond(params);
        return;
      }
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'no such endpoint' } }));

      function respond(params) {
        if (opts.status !== 200) {
          res.writeHead(opts.status, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: { message: opts.message || 'mock error' } }));
          return;
        }
        const out = { model: params.model };
        if (opts.streamRequested && params.stream) {
          res.writeHead(200, { 'Content-Type': 'text/event-stream' });
          const usageFrame = opts.usage
            ? 'data: ' + JSON.stringify({ usage: { prompt_tokens: 10, completion_tokens: 20, total_tokens: 30 } }) + '\n\n'
            : '';
          res.end(
            'data: ' + JSON.stringify({ choices: [{ delta: { content: 'Hel' } }] }) + '\n\n' +
            'data: ' + JSON.stringify({ choices: [{ delta: { content: 'lo' }, finish_reason: 'stop' }] }) + '\n\n' +
            usageFrame +
            'data: [DONE]\n\n'
          );
          return;
        }
        out.choices = [{ message: { content: 'Hello' }, finish_reason: 'stop' }];
        out.usage = opts.usage
          ? { prompt_tokens: 10, completion_tokens: 20, total_tokens: 30 }
          : undefined;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(out));
      }
    });
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  return { server, hits, baseUrl: 'http://127.0.0.1:' + port + '/v1' };
}

function baseConfig(baseUrl, extra) {
  return Object.assign({
    baseUrl,
    apiKey: VALID_KEY,
    model: 'model-a',
    requests: 4,
    maxTokens: 64,
    concurrency: 2,
    timeoutMs: 15000,
    prompt: 'hi',
    mode: 'usage'
  }, extra);
}

// ---------------------------------------------------------------- engine ---

test('engine: runs real requests and aggregates usage', async () => {
  const m = await startMock();
  try {
    const seen = [];
    const out = await engine.run(baseConfig(m.baseUrl), {
      onRecord: (r) => seen.push(r.ok && r.hasUsage)
    });
    assert.equal(out.ok, true);
    assert.equal(out.records.length, 4);
    assert.equal(m.hits.chat, 4);
    assert.ok(seen.every(Boolean));
    assert.equal(out.summary.totalTokens, 120);
    assert.equal(out.summary.dataComplete, true);
    assert.equal(out.summary.requestStats.requestsWithUsage, 4);
  } finally { m.server.close(); }
});

test('engine: invalid key is fatal and stops the batch early', async () => {
  const m = await startMock();
  try {
    const out = await engine.run(baseConfig(m.baseUrl, { apiKey: 'sk-wrong', requests: 10, concurrency: 3 }));
    assert.equal(out.ok, true);
    assert.equal(out.summary.fatalCode, 'INVALID_KEY');
    assert.equal(out.summary.dataComplete, false);
    assert.equal(out.records.length, 3, 'one fatal per worker, then stop');
  } finally { m.server.close(); }
});

test('engine: rejects missing required fields without throwing', async () => {
  const bad = engine.normalizeConfig({ baseUrl: '', apiKey: 'x', model: 'm' });
  assert.equal(bad.ok, false);
  assert.equal(bad.field, 'baseUrl');
  const out = await engine.run({ baseUrl: 'https://x.invalid', apiKey: '', model: 'm' });
  assert.equal(out.ok, false);
});

test('engine: clamps unsafe values', () => {
  const n = engine.normalizeConfig(baseConfig('https://x/v1', { requests: 99999, concurrency: 999, maxTokens: 0 }));
  assert.ok(n.config.requests <= engine.LIMITS.requests.max);
  assert.ok(n.config.concurrency <= engine.LIMITS.concurrency.max);
  assert.ok(n.config.concurrency <= n.config.requests);
  assert.ok(n.config.maxTokens >= 1);
});

test('engine: API without usage records the fact honestly', async () => {
  const m = await startMock({ usage: false });
  try {
    const out = await engine.run(baseConfig(m.baseUrl));
    assert.equal(out.ok, true);
    assert.equal(out.summary.requestStats.requestsWithUsage, 0);
    assert.equal(out.summary.dataComplete, false);
    assert.equal(out.records[0].errorCode, 'NO_USAGE');
    assert.equal(out.records[0].totalTokens, null, 'no token figure may be invented');
  } finally { m.server.close(); }
});

test('engine: SSE stream picks up final usage frame', async () => {
  const m = await startMock({ streamRequested: true });
  try {
    let deltas = 0;
    const out = await engine.run(baseConfig(m.baseUrl, { stream: true }), {
      onDelta: () => { deltas++; }
    });
    assert.equal(out.ok, true);
    assert.ok(deltas >= 2);
    assert.equal(out.records[0].streamed, true);
    assert.equal(out.records[0].totalTokens, 30);
    assert.equal(out.summary.dataComplete, true);
  } finally { m.server.close(); }
});

// ------------------------------------------------------------- api utils ---

test('api: listModels deduplicates and reports unsupported endpoints', async () => {
  const m = await startMock();
  try {
    const okList = await api.listModels({ baseUrl: m.baseUrl, apiKey: VALID_KEY });
    assert.deepEqual(okList.models.map((x) => x.id), ['model-a', 'model-b']);

    const noModels = await startMock({ killModels: true });
    try {
      await assert.rejects(
        api.listModels({ baseUrl: noModels.baseUrl, apiKey: VALID_KEY }),
        (err) => err.code === 'MODELS_UNSUPPORTED'
      );
    } finally { noModels.server.close(); }
  } finally { m.server.close(); }
});

test('api: probeBalance finds DeepSeek-style balance or reports unavailable', async () => {
  const m = await startMock();
  try {
    const probed = await api.probeBalance({ baseUrl: m.baseUrl, apiKey: VALID_KEY });
    assert.equal(probed.available, true);
    assert.equal(probed.amount, 50);
    assert.equal(probed.currency, 'CNY');

    // A relay without any balance endpoint: probe every path, get 404s.
    const bare = await startMock({ status: 404, killBalance: true });
    try {
      const none = await api.probeBalance({ baseUrl: bare.baseUrl, apiKey: VALID_KEY });
      assert.equal(none.available, false);
    } finally { bare.server.close(); }
  } finally { m.server.close(); }
});

// ----------------------------------------------------------- verification ---

test('verify: token-unit verification detects exact, drifted and missing cases', async () => {
  const m = await startMock();
  try {
    // 4 requests x 30 tokens = 120 API tokens per round.
    const cfg = (before, after) => baseConfig(m.baseUrl, {
      mode: 'verification', requests: 4, concurrency: 1,
      repeat: 1, accountUnit: 'tokens', tolerancePercent: 1,
      balanceBefore: before, balanceAfter: after
    });

    const exact = await verify.runRepeated(cfg(1000, 880));
    assert.equal(exact.status, 'normal');
    assert.equal(exact.conclusionKey, 'result.normal');
    assert.equal(exact.dataComplete, true);

    const drifted = await verify.runRepeated(cfg(1000, 830));
    assert.equal(drifted.status, 'discrepancy');
    // 4 reqs * 30 tokens = 120 API tokens; delta = 170 => 41.67%
    assert.ok(Math.abs(drifted.roundRecords[0].discrepancyRate - 41.66666666666667) < 1e-9);

  } finally { m.server.close(); }

  // "No data" must come from a relay with no balance endpoint at all; the main
  // mock exposes one, so a separate no-balance server verifies the honest path.
  const noBal = await startMock({ killBalance: true });
  try {
    const out = await verify.runRepeated(baseConfig(noBal.baseUrl, {
      mode: 'verification', requests: 2, concurrency: 1, repeat: 1,
      accountUnit: 'tokens', tolerancePercent: 1
    }));
    assert.equal(out.status, 'insufficient');
    assert.equal(out.conclusionKey, 'result.insufficient');
    assert.equal(out.dataComplete, false);
  } finally { noBal.server.close(); }
});

test('verify: repeated rounds aggregate with weighted rate and stability', async () => {
  const m = await startMock();
  try {
    const out = await verify.runRepeated(baseConfig(m.baseUrl, {
      mode: 'verification', requests: 2, concurrency: 1,
      repeat: 3, accountUnit: 'tokens', tolerancePercent: 1,
      balanceBefore: undefined, balanceAfter: undefined
    }));
    assert.equal(out.ok, true);
    assert.equal(out.rounds.length, 3);
    assert.equal(m.hits.chat, 6);
    assert.equal(out.stats.roundCount, 3);
  } finally { m.server.close(); }
});

test('verify: manual balance beats a failed probe; auto probe wins when present', async () => {
  const m = await startMock();
  try {
    const manual = verify.resolveBalance('9.5', { available: false }, 'before');
    assert.equal(manual.source, 'manual');
    assert.equal(manual.amount, 9.5);

    const auto = verify.resolveBalance(null, { available: true, amount: 50, source: 'user/balance' }, 'before');
    assert.equal(auto.source, 'api:user/balance');

    const none = verify.resolveBalance('', { available: false }, 'before');
    assert.equal(none.available, false);
    assert.equal(none.amount, null);
  } finally { m.server.close(); }
});

// ---------------------------------------------------------------- report ---

test('report: usage report never includes the key and flags missing usage', async () => {
  const m = await startMock({ usage: false });
  try {
    const out = await engine.run(baseConfig(m.baseUrl, { requests: 2, concurrency: 1 }));
    const rep = report.build(out, { locale: 'en-US', tolerancePercent: 1 });
    assert.equal(rep.mode, 'usage');
    assert.equal(rep.configuration.apiKey, '[not included]');
    assert.equal(rep.completeness.complete, false);
    assert.ok(rep.completeness.notes.some((n) => n.includes('did not return Token Usage')));

    const json = report.toJSON(rep);
    assert.equal(report.assertNoSecrets(json), true);
    assert.ok(!json.includes(VALID_KEY));

    const csv = report.toCSV(rep);
    assert.ok(csv.includes('[requests]'));
    assert.ok(!csv.includes(VALID_KEY));
  } finally { m.server.close(); }
});

test('report: verification report carries neutral statements and round table', async () => {
  const m = await startMock();
  try {
    const out = await verify.runRepeated(baseConfig(m.baseUrl, {
      mode: 'verification', requests: 2, concurrency: 1, repeat: 3,
      accountUnit: 'tokens', tolerancePercent: 1
    }));
    const rep = report.build(out, { locale: 'en-US', tolerancePercent: 1 });
    assert.equal(rep.mode, 'verification');
    assert.equal(rep.rounds.length, 3);
    assert.ok(rep.result.statement.length > 0);

    const csv = report.toCSV(rep);
    assert.ok(csv.includes('[rounds]'));
    assert.ok(csv.includes('[requests]'));

    const name = report.suggestFilename(rep, 'json');
    assert.match(name, /^ai-relay-meter-verification-\d{8}-\d{6}\.json$/);
  } finally { m.server.close(); }
});

test('report: round-trips through stats without re-deriving', () => {
  const fake = statsLib.summarizeRequests([
    { ok: true, hasUsage: true, status: 200, latencyMs: 10, promptTokens: 1, completionTokens: 2, totalTokens: 3 }
  ]);
  assert.equal(fake.totalTokens.sum, 3);
});
