/**
 * Unit tests: core modules (usage, diff, stats, errors, mask).
 * Run with: npm test
 */
const test = require('node:test');
const assert = require('node:assert');

const usage = require('../src/js/core/usage.js');
const diff = require('../src/js/core/diff.js');
const stats = require('../src/js/core/stats.js');
const errors = require('../src/js/core/errors.js');
const mask = require('../src/js/core/mask.js');

// ---------------------------------------------------------------- usage ----

test('usage: normalizes standard OpenAI usage', () => {
  const u = usage.normalizeUsage({ prompt_tokens: 5, completion_tokens: 7, total_tokens: 12 });
  assert.equal(u.hasUsage, true);
  assert.equal(u.promptTokens, 5);
  assert.equal(u.completionTokens, 7);
  assert.equal(u.totalTokens, 12);
});

test('usage: extracts cached and reasoning tokens across dialects', () => {
  const openai = usage.normalizeUsage({
    prompt_tokens: 10, completion_tokens: 4, total_tokens: 14,
    prompt_tokens_details: { cached_tokens: 3 },
    completion_tokens_details: { reasoning_tokens: 2 }
  });
  assert.equal(openai.cachedTokens, 3);
  assert.equal(openai.reasoningTokens, 2);

  const deepseek = usage.normalizeUsage({
    prompt_tokens: 10, completion_tokens: 4, total_tokens: 14,
    prompt_cache_hit_tokens: 6
  });
  assert.equal(deepseek.cachedTokens, 6);
});

test('usage: missing usage is flagged, never fabricated', () => {
  const none = usage.normalizeUsage(undefined);
  assert.equal(none.hasUsage, false);
  assert.equal(none.totalTokens, null);
  assert.equal(none.reason, 'missing');

  const empty = usage.normalizeUsage({});
  assert.equal(empty.hasUsage, false);
  assert.equal(empty.reason, 'no_token_fields');
});

test('usage: accountableTokens prefers reported total, flags derived sums', () => {
  const withTotal = usage.accountableTokens(
    usage.normalizeUsage({ prompt_tokens: 5, completion_tokens: 7, total_tokens: 12 })
  );
  assert.equal(withTotal.tokens, 12);
  assert.equal(withTotal.derived, false);

  const derived = usage.accountableTokens(
    usage.normalizeUsage({ prompt_tokens: 5, completion_tokens: 7 })
  );
  assert.equal(derived.tokens, 12);
  assert.equal(derived.derived, true);

  const none = usage.accountableTokens(usage.normalizeUsage(undefined));
  assert.equal(none.tokens, null);
});

// ----------------------------------------------------------------- diff ----

test('diff: computes token difference and discrepancy rate', () => {
  const d = diff.computeTokenDifference(1000, 1010);
  assert.equal(d.difference, 10);
  assert.equal(d.discrepancyRate, 1.0);
});

test('diff: insufficient when either side is missing', () => {
  assert.equal(diff.computeTokenDifference(null, 100).status, 'insufficient');
  assert.equal(diff.computeTokenDifference(100, undefined).status, 'insufficient');
  assert.equal(diff.computeTokenDifference(100, undefined).discrepancyRate, null);
});

test('diff: zero baseline yields null rate, not Infinity', () => {
  const d = diff.computeTokenDifference(0, 0);
  assert.equal(d.discrepancyRate, null);
});

test('diff: classify within tolerance is normal', () => {
  const v = diff.classify(diff.computeTokenDifference(1000, 1005), 1);
  assert.equal(v.status, 'normal');
  assert.equal(v.conclusionKey, 'result.normal');
});

test('diff: classify beyond tolerance is discrepancy', () => {
  const v = diff.classify(diff.computeTokenDifference(1000, 1100), 1);
  assert.equal(v.status, 'discrepancy');
});

test('diff: cost layer is computed independently', () => {
  const c = diff.computeCostDifference(1.5, 1.5);
  assert.equal(c.difference, 0);
  const missing = diff.computeCostDifference(null, 2);
  assert.equal(missing.status, 'insufficient');
});

test('diff: analyze overall verdict follows the weaker layer', () => {
  const both = diff.analyze({
    apiTokens: 1000, accountTokens: 1000,
    theoreticalCost: 1.0, actualCost: 3.0, accountUnit: 'currency'
  });
  assert.equal(both.status, 'discrepancy');
  assert.equal(both.dataCompleteness.theoreticalCost, true);
});

test('diff: account usage from balance delta', () => {
  const a = diff.computeAccountUsage(10.0, 9.9, 'currency');
  assert.ok(Math.abs(a.value - 0.1) < 1e-9);
  assert.equal(a.unit, 'currency');
  const missing = diff.computeAccountUsage(null, 5, 'tokens');
  assert.equal(missing.value, null);
});

// ---------------------------------------------------------------- stats ----

test('stats: describe computes mean/median/min/max/stdev', () => {
  const d = stats.describe([1, 2, 3, 4, 10]);
  assert.equal(d.count, 5);
  assert.equal(d.sum, 20);
  assert.equal(d.min, 1);
  assert.equal(d.max, 10);
  assert.equal(d.median, 3);
  assert.ok(d.stdev > 0);
  assert.equal(stats.describe([]).mean, null);
});

test('stats: summarizeRequests only counts usage-bearing successes', () => {
  const r = stats.summarizeRequests([
    { ok: true, hasUsage: true, status: 200, latencyMs: 100, promptTokens: 10, completionTokens: 20, totalTokens: 30 },
    { ok: true, hasUsage: false, status: 200, latencyMs: 50 },
    { ok: false, errorCode: 'INVALID_KEY', status: 401, latencyMs: 20 }
  ]);
  assert.equal(r.totalRequests, 3);
  assert.equal(r.successCount, 2);
  assert.equal(r.failureCount, 1);
  assert.equal(r.requestsWithUsage, 1);
  assert.equal(r.totalTokens.sum, 30);
  assert.deepEqual(r.errorCodeCounts, { INVALID_KEY: 1 });
});

test('stats: summarizeRounds aggregates discrepancy stability', () => {
  const s = stats.summarizeRounds([
    { apiTokens: 1000, accountTokens: 1005, discrepancyRate: 0.5 },
    { apiTokens: 2000, accountTokens: 2010, discrepancyRate: 0.5 }
  ]);
  assert.equal(s.roundCount, 2);
  assert.equal(s.stability, 'stable');
  assert.equal(s.discrepancyRate.mean, 0.5);
  assert.equal(stats.summarizeRounds([{ apiTokens: 1 }]).stability, 'unknown');
});

test('stats: weighted rate resists small-round domination', () => {
  const w = stats.weightedDiscrepancyRate([
    { apiTokens: 100, accountTokens: 200, discrepancyRate: 100 },
    { apiTokens: 10000, accountTokens: 10100, discrepancyRate: 1 }
  ]);
  // (100 + 100) / (100 + 10000) * 100 ~ 1.98, not the arithmetic 50.5
  assert.ok(w > 1.9 && w < 2.0, 'weighted=' + w);
});

// --------------------------------------------------------------- errors ----

test('errors: maps HTTP statuses to codes and fatality', () => {
  assert.equal(errors.fromStatus(401).code, 'INVALID_KEY');
  assert.equal(errors.fromStatus(401).fatal, true);
  assert.equal(errors.fromStatus(402).code, 'INSUFFICIENT_QUOTA');
  assert.equal(errors.fromStatus(403).code, 'FORBIDDEN');
  assert.equal(errors.fromStatus(404).fatal, true);
  assert.equal(errors.fromStatus(429).retryable, true);
  assert.equal(errors.fromStatus(500).retryable, true);
  assert.equal(errors.fromStatus(502).code, 'BAD_GATEWAY');
  assert.equal(errors.fromStatus(200).code, 'UNKNOWN');
});

test('errors: classifies exceptions', () => {
  const abort = errors.fromException(Object.assign(new Error('The operation was aborted'), { name: 'AbortError' }));
  assert.equal(abort.code, 'ABORTED');
  assert.equal(errors.fromException(new Error('Request timeout after 5ms')).code, 'TIMEOUT');
  assert.equal(errors.fromException(new TypeError('Failed to fetch')).code, 'CORS');
  assert.equal(errors.fromException(new Error('getaddrinfo ENOTFOUND api.bad')).code, 'NETWORK');
});

test('errors: shouldAbortRun stops only on fatal or abort', () => {
  assert.equal(errors.shouldAbortRun(errors.fromStatus(401)), true);
  assert.equal(errors.shouldAbortRun(errors.fromStatus(429)), false);
  assert.equal(errors.shouldAbortRun(errors.fromStatus(500)), false);
});

// ----------------------------------------------------------------- mask ----

test('mask: masks keys keeping head and tail', () => {
  assert.equal(mask.maskKey('sk-abcdefghijklmnop1234'), 'sk-abc************1234');
});

test('mask: fully masks short keys', () => {
  assert.equal(mask.maskKey('short'), '*****');
  assert.equal(mask.maskKey(''), '');
  assert.equal(mask.maskKey(null), '');
});

test('mask: scrubs bearer tokens and key shapes from text', () => {
  const s = mask.scrubText('Authorization: Bearer sk-abcdefghijklmnop1234 failed');
  assert.ok(!s.includes('sk-abcdefghijklmnop1234'), s);
  assert.ok(mask.looksUnmasked('live key sk-abcdefghijklmnop1234 here'));
  assert.equal(mask.looksUnmasked(mask.scrubText('key sk-abcdefghijklmnop1234')), false);
});

test('mask: safeHeaders redacts auth headers', () => {
  const h = mask.safeHeaders({ Authorization: 'Bearer sk-secret-key-123456', Accept: 'application/json' });
  assert.ok(!h.Authorization.includes('sk-secret-key-123456'));
  assert.equal(h.Accept, 'application/json');
});
