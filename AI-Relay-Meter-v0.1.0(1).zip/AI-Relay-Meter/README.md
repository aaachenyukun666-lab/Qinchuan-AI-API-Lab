# AI Relay Meter

**AI API Token Meter & Relay Verification Tool**

[简体中文](README.zh-CN.md) · English

AI Relay Meter is a developer tool for measuring the token usage reported by
OpenAI-compatible APIs and for running small-scale usage verification against
relay or gateway endpoints.

It sends real, deliberately small API requests, records the `usage` object the
server actually returns, and — when the provider exposes a balance or quota
figure — compares the account before and after a test run. The result is a
reviewable data set you can export and re-run, not a verdict.

---

## Table of Contents

- [What It Is](#what-it-is)
- [Features](#features)
- [Screenshots](#screenshots)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Test Modes](#test-modes)
- [Verification & Discrepancy](#verification--discrepancy)
- [Report Export](#report-export)
- [Internationalization](#internationalization)
- [Security Notes](#security-notes)
- [Android APK Packaging (WebCatX)](#android-apk-packaging-webcatx)
- [Development](#development)
- [Testing](#testing)
- [Roadmap](#roadmap)
- [License](#license)

---

## What It Is

Most developers interact with LLM traffic through a relay or gateway rather than
directly with a model vendor. That layer is convenient, but it sits between you
and the numbers: the `usage` object in the response and the amount actually
deducted from your account are two separate observations, and nothing forces
them to agree.

AI Relay Meter is a measuring instrument for that gap. It:

1. Sends real requests to an OpenAI-compatible `Base URL` you specify.
2. Records the token usage **exactly as the API reported it**, field by field.
3. Optionally records an account balance/quota reading before and after a run.
4. Computes the token-level and cost-level differences between the two.
5. Exports the raw records so anyone can re-check the arithmetic.

It is a developer tool, an API usage measurement tool, and an API testing tool.
It does not audit, accuse, or rank providers. When the data is incomplete, it
says so instead of guessing.

**Who it is for:** developers evaluating a relay provider, integrators debugging
token accounting, and anyone who wants reproducible usage numbers rather than a
dashboard screenshot.

## Features

- **OpenAI-compatible by design.** Any `Base URL` that speaks the Chat
  Completions protocol. No provider is hard-coded as the only option.
- **Model discovery.** `GET /models` populates a selectable list. If the
  endpoint is missing or unauthorized, the app degrades to manual model entry
  instead of failing.
- **Two test modes.** `Token Usage Test` for throughput, latency, and stability;
  `Small-scale Verification` for conservative, low-cost verification runs.
- **Full usage capture.** `prompt_tokens`, `completion_tokens`, `total_tokens`,
  plus `prompt_tokens_details`, `completion_tokens_details`, `cached_tokens`,
  and `reasoning_tokens` when the provider returns them.
- **No fabricated numbers.** If the API omits `usage`, the record is marked
  `API 未返回 Token Usage` / `No Token Usage returned by the API`. Estimated
  values are never presented as measured ones.
- **Streaming and non-streaming.** SSE streaming is supported and the final
  `usage` frame is read when the provider sends one. If a stream ends without
  usage, the result is flagged as possibly incomplete.
- **Balance / quota comparison.** Reads before/after values when a provider
  exposes them, and accepts manual entry when it does not.
- **Separated token and cost accounting.** Token deltas and monetary deltas are
  never conflated, because relay pricing commonly involves multipliers,
  input/output price tiers, cache pricing, reasoning tokens, and minimum
  billable units.
- **Repeat verification with aggregation.** Run 3, 5, or N iterations and get
  mean API tokens, mean account deduction, mean discrepancy rate, and the
  min/max spread — so you can judge whether a difference is stable.
- **Neutral result language.** Outcomes are expressed as *no significant usage
  discrepancy detected*, *a usage or billing discrepancy was detected —
  repeated testing is recommended*, or *insufficient data for full
  verification*.
- **JSON and CSV export.** Full per-request detail plus session summary.
- **Complete zh-CN / en-US internationalization**, switchable at runtime without
  losing configuration, in-flight tests, or results.
- **Local-only secrets.** API keys live in `localStorage` and are masked in all
  logs and reports.
- **Conservative defaults.** 3 requests, `max_tokens: 100`, concurrency 1.
- **Runs anywhere.** A plain static page in the browser, or a packaged Android
  APK via WebCatX.

## Screenshots

> Screenshot placeholders. The images below are not yet captured from a running
> build — replace each placeholder with a real capture before the first tagged
> release.

| View | Description | File |
| --- | --- | --- |
| Main screen | API configuration, test mode, parameters, start/stop | `docs/images/main.png` *(placeholder)* |
| Live results | Running totals, latency, request count, progress | `docs/images/live-results.png` *(placeholder)* |
| Verification panel | API usage, account usage, difference, discrepancy rate | `docs/images/verification.png` *(placeholder)* |
| Report view | Session summary and per-request detail, export actions | `docs/images/report.png` *(placeholder)* |

## Quick Start

### Prerequisites

- **Node.js 18 or newer** (for the local server, locale build, and tests).
- A modern browser, or WebCatX for Android packaging.
- An OpenAI-compatible `Base URL` and API key.

### Run it locally

```bash
git clone https://github.com/<your-org>/AI-Relay-Meter.git
cd AI-Relay-Meter
npm install
npm run build:locales
npm run serve
```

Then open <http://127.0.0.1:4173>.

`npm run build:locales` generates `locales/*.js` from `locales/*.json`. Run it
once after cloning; without it, the `file://` path has no locale bundles to
load.

### First run in three steps

1. Enter your `Base URL`, `API Key`, and — if you like — click **Get Models** to
   pick one instead of typing it.
2. Choose **Small-scale Verification** and leave the defaults alone
   (3 requests, `max_tokens: 100`, concurrency 1).
3. Press **Start Test**, then open **View Detailed Report** and export the JSON.

### Open the page directly from disk

Because the app ships as plain classic scripts and pre-generated locale bundles,
you can also open `index.html` straight from the filesystem with no server:

```bash
npm run build:locales   # required once, so locales/*.js exist
xdg-open index.html     # or open the file in your browser
```

This is the same code path the Android build uses. See
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for why that constraint shapes the
project.

## Configuration

All three fields live in the API Configuration card on the main screen.

| Field | Required | Notes |
| --- | --- | --- |
| **Base URL** | Yes | Root of an OpenAI-compatible API, e.g. `https://api.example.com/v1`. Trailing slashes are normalized. The app appends `/chat/completions` and `/models`. |
| **API Key** | Yes | Sent as `Authorization: Bearer <key>`. Stored only in the browser's `localStorage` on your device. |
| **Model** | Yes | Free-text, or selected from the `GET /models` result list. Nothing is hard-coded. |

**Get Models** issues `GET {Base URL}/models`. If the endpoint returns 401, 403,
404, an empty list, or malformed JSON, the app reports the specific failure and
keeps manual model entry available. A missing `/models` endpoint never blocks
testing.

Configuration is persisted locally and restored on the next launch. Clearing
site data removes it. Language selection is stored separately and never resets
your API configuration.

## Test Modes

### Token Usage Test

For measuring general consumption, throughput, latency, and request stability.

| Parameter | Default | Description |
| --- | --- | --- |
| Requests | 3 | Number of requests to issue in the run |
| Max Tokens | 100 | `max_tokens` sent with each request |
| Concurrency | 1 | Number of parallel in-flight requests |
| Model | — | From configuration |
| Prompt | built-in short prompt | Deliberately small to limit cost |

Each request records: request index, timestamp, model, prompt tokens,
completion tokens, total tokens, latency (ms), HTTP status, and error.

### Small-scale Verification

The conservative mode, and the recommended starting point. It uses the same
request engine with deliberately small defaults — **3 requests, `max_tokens`
100, concurrency 1** — and adds the before/after account comparison and the
discrepancy analysis on top.

Every request in this mode is a **real** API call. Nothing is simulated locally,
and no token counts are synthesized.

A prominent **Stop Test** button is always available while a run is active.
In-flight requests are aborted and partial results are retained rather than
discarded.

Parameters are user-adjustable. Raising them increases real API consumption —
the defaults exist to prevent accidental spend.

## Verification & Discrepancy

When verification runs, the app presents these quantities:

| Quantity | Meaning |
| --- | --- |
| API-reported Token Usage | Token counts returned by the API's `usage` field |
| Account Usage / Platform Token Count | Token or quota figure from the provider's own accounting, when available |
| Difference | `Account Usage − API-reported Usage` |
| Discrepancy Rate | `\|Account Usage − API-reported Usage\| / API-reported Usage × 100%` |

Token-level and cost-level figures are reported **separately**. A token count is
not a currency amount, and the tool never converts one into the other. Where a
provider applies multipliers, input/output price tiers, cache pricing, reasoning
token pricing, minimum billable units, or other rules, the theoretical cost and
the observed cost are recorded as distinct fields.

Results are expressed in neutral terms only:

- **No significant usage discrepancy detected.** / 未检测到明显计量差异。
- **A usage or billing discrepancy was detected. Repeated testing is
  recommended.** / 检测到 Token / 费用统计差异，建议进行重复测试。
- **Insufficient data for full verification.** / 当前数据不足，无法完成完整验真。

A single run never produces a conclusion about a provider. The tool measures,
records, compares, and displays. Judging whether a difference is meaningful —
and whether it is stable across runs — is left to you, with the raw data
exported alongside the summary so the arithmetic can be checked independently.

If a provider exposes no balance or quota endpoint, you can enter the before and
after values manually. If the required values are missing entirely, the app
reports that full verification is not possible rather than estimating.

## Report Export

Every run produces a report containing:

- Test timestamp, `Base URL`, and model
- Number of iterations
- Total prompt tokens, total completion tokens, total tokens
- When available: balance before, balance after, actual deduction, theoretical
  cost, actual cost, token difference, cost difference, discrepancy rate
- A data-completeness note stating which fields could not be obtained
- Per-request detail in addition to the aggregate summary

Export formats:

- **JSON** — the complete structured record, suitable for diffing and archival.
- **CSV** — one row per request plus a summary row, suitable for spreadsheets.

Reports are rendered in the active language. API keys never appear in a report
in cleartext.

## Internationalization

Simplified Chinese (`zh-CN`) and English (`en-US`) are both complete, in a
single codebase — not two parallel forks.

- On first launch the language is chosen from the system locale: `zh-CN` / `zh`
  selects Chinese; anything else selects English.
- The switcher is available in the top-right corner of the main screen.
- The choice is persisted locally.
- Switching language **never** clears API configuration, test history, token
  data, or results, and is permitted while a test is running. Test data is
  unaffected.

All user-visible UI, buttons, errors, help text, settings, and reports are
translated. Standard technical terms — API, Token, OpenAI, DeepSeek, OpenRouter,
JSON, HTTP, HTTPS, REST, SSE — remain in English by convention.

Locale resources live in `locales/`:

```text
locales/zh-CN.json   # canonical source
locales/en-US.json
locales/zh-CN.js     # generated by `npm run build:locales`, for file:// use
locales/en-US.js
```

`zh-CN.json` is the canonical reference. When adding a string, add it there
first, then mirror it in `en-US.json`, then regenerate.

## Security Notes

- **API keys are local only.** A key is stored in the browser's `localStorage`
  on your device and sent exclusively to the `Base URL` you configured. It is
  never uploaded anywhere else.
- **No hard-coded credentials.** The source contains no API key or provider
  secret.
- **Log masking.** Keys are masked before appearing in any log line, message, or
  exported report — for example `sk-1234************abcd`. Only a short prefix
  and suffix are retained, which is enough to identify which key was used.
- **Reports are safe to share.** Masking applies to report output as well, so an
  exported JSON or CSV can be attached to a bug report.
- **No third-party telemetry.** The app makes no analytics or tracking requests.
  Outbound traffic goes only to the `Base URL` you enter.
- **Static and auditable.** There is no bundler and no build-time code
  generation beyond the locale bundles, so what you read in `src/js/` is what
  runs.
- **Local server binds to loopback.** `npm run serve` listens on `127.0.0.1`.

Your API key grants access to a billable account. Prefer a scoped or
low-balance key when testing an unfamiliar relay, and clear site data if you
share the machine.

## Android APK Packaging (WebCatX)

The project packages into an Android app with **WebCatX**, which wraps the
static page in a WebView and exposes native capabilities through its
`window.webcat` bridge. No Android SDK, Gradle, or Java toolchain is required.

### Steps

1. **Prepare the locale bundles.** Run `npm run build:locales` so
   `locales/zh-CN.js` and `locales/en-US.js` exist. Without them the packaged
   app cannot load translations offline.
2. **Assemble the packaging directory.** Copy the runtime files — see the list
   below. `node_modules/`, `tests/`, and `scripts/` are not needed inside the
   APK.
3. **Open WebCatX** and create a new project, pointing its project directory at
   the assembled folder.
4. **Set the start page** to `index.html` (the `启动页面` field in
   `appConfig.xlt`). The app is a single page; no routing is involved.
5. **Configure app identity** in `appConfig.xlt`: `appName`, `appPackageName`,
   `appVersionName`, `appVersionCode`.
6. **Declare permissions.** The verification flow needs only network access. Add
   storage permissions *only* if you extend the app to write exports to a public
   directory; the default build keeps exports inside the app.
7. **Build the APK** from WebCatX, then install it on a device or emulator.
8. **Smoke-test on the device** — see the checklist below.

### Files to include in the packaging directory

```text
index.html
assets/appIcon.png
locales/*.json
locales/*.js          # generated — do not skip
src/css/style.css
src/js/**/*.js
appConfig.xlt
```

### `appConfig.xlt` field reference

The bundled configuration is a starting point; the values below are what each
field controls.

| Field | Meaning | Suggested value |
| --- | --- | --- |
| `appName` | App name shown on the launcher | `AI Relay Meter` |
| `appPackageName` | Android application ID; must be unique and stable across releases | your own reverse-DNS ID |
| `appVersionName` | Human-readable version | `0.1.0` |
| `appVersionCode` | Monotonic integer; must increase for every release | `10000` |
| `data.启用顶栏` | Show the native title bar | `true` |
| `data.顶栏标题` | Title bar text | `AI Relay Meter` |
| `data.顶栏颜色` | Title bar color as `#AARRGGBB` | match the app theme |
| `data.横屏` | Lock to landscape | `false` |
| `data.显示状态栏` | Show the system status bar | `true` |
| `data.启用进度条` | Show the native loading progress bar | `true` |
| `data.进度条颜色` | Progress bar color; `#00000000` renders it invisible | `#00000000` |
| `data.支持打开外部应用` | Allow `webcat.browser` / deep links to leave the app | `true` |
| `data.提示打开外部应用` | Confirm before leaving the app | `false` |
| `data.启动页面` | Entry page, relative to the project root | `index.html` |
| `indexPages` | Additional pages preloaded into the WebView | leave empty |
| `extraHeaders` | Extra HTTP headers injected into page requests | leave empty |

### Notes for this project

- **The app loads from `file://`.** This is why `src/js/` uses UMD-style
  classic scripts and why `locales/*.js` are generated: ES modules
  (`type="module"`) are blocked by the WebView's CORS policy on `file://`,
  whereas a classic `<script src>` loads fine offline.
- **Network access comes from the WebView.** Requests to the configured
  `Base URL` must be reachable from the device and must permit cross-origin
  calls, since the page origin is `file://`. Providers that reject browser
  origins will fail here. WebCatX additionally offers
  `webcat.network.request`, a native, CORS-free transport — see
  [docs/webcat-api.md](docs/webcat-api.md) — which is the extension point if you
  need to reach such providers.
- **Exports.** Downloading from a `file://` page behaves differently than over
  HTTP. If the browser path does not produce a file on device, route the export
  through `webcat.media.save` or `webcat.fs.writeFile` (both documented in
  [docs/webcat-quick.md](docs/webcat-quick.md)).
- **Status bar spacing.** WebCatX already handles status-bar insets. Do not add
  compensating padding to the header unless you explicitly enable
  `setAdaptive(true)` immersion.

### Device smoke test

After installing the APK, confirm:

1. The app launches and renders the main screen (no blank page).
2. Language switching works and survives a restart.
3. `Get Models` succeeds, or fails gracefully with a readable message.
4. A single `Small-scale Verification` run completes with conservative
   defaults.
5. **Stop Test** aborts an in-flight run.
6. An export produces a file you can open.
7. A deliberately wrong API key produces a readable `401` message and does not
   crash the app.

For the full bridge reference, see [docs/webcat-api.md](docs/webcat-api.md) and
[docs/webcat-quick.md](docs/webcat-quick.md).

## Development

### Requirements

- Node.js 18+
- A modern browser

No bundler, no framework, no transpiler. `src/js/` is loaded directly by the
browser.

### Directory structure

```text
AI-Relay-Meter/
├── README.md              # English (GitHub default)
├── README.zh-CN.md        # Chinese
├── LICENSE                # MIT
├── CHANGELOG.md
├── package.json
├── index.html             # single-page app entry
├── assets/appIcon.png
├── locales/               # zh-CN.json is canonical; *.js are generated
├── src/
│   ├── css/style.css
│   └── js/
│       ├── app.js         # UI assembly and flow orchestration
│       ├── api.js         # OpenAI-compatible client, incl. SSE streaming
│       ├── engine.js      # Token Usage Test engine
│       ├── verify.js      # Small-scale Verification and discrepancy analysis
│       ├── report.js      # report building, JSON / CSV export
│       ├── i18n.js
│       ├── store.js       # localStorage configuration persistence
│       └── core/
│           ├── usage.js   # usage normalization
│           ├── diff.js    # token / cost difference calculation
│           ├── errors.js  # error classification
│           ├── mask.js    # API key masking
│           └── stats.js   # repeat-test aggregation
├── docs/
│   ├── ARCHITECTURE.md
│   ├── webcat-api.md
│   └── webcat-quick.md
├── demo/                  # local mock server for offline demos
├── android/               # WebCatX packaging configuration and notes
├── scripts/
│   ├── serve.mjs          # static server
│   ├── build-locales.mjs  # locales/*.json -> locales/*.js
│   └── live-check.mjs     # real-API smoke check
└── tests/                 # node --test unit and integration tests
```

### npm commands

| Command | What it does |
| --- | --- |
| `npm run serve` | Static server on <http://127.0.0.1:4173> |
| `npm run build:locales` | Generate `locales/*.js` from `locales/*.json` |
| `npm test` | `node --test tests/` |
| `npm run test:live` | Real-API smoke check |

### Module loading convention

`src/js/` files are **UMD-style classic scripts**, not ES modules. Each file
attaches itself to the `window.ARM` namespace (`ARM.usage`, `ARM.api`,
`ARM.engine`, and so on) while remaining `require()`-able from Node for tests:

```js
(function (root, factory) {
  if (typeof module === 'object' && module.exports) { module.exports = factory(); }
  else { root.ARM = root.ARM || {}; root.ARM.usage = factory(); }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  // ...
  return { normalizeUsage: normalizeUsage };
});
```

Consequently `package.json` does **not** set `"type": "module"`. This is what
lets one copy of each source file serve both the browser (via `<script src>`,
which works offline over `file://`) and `node --test` (via `require`), with no
build step. See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the full
rationale.

### Local demo

`demo/` contains a mock OpenAI-compatible endpoint for offline development. It
lets you exercise the full flow — including deliberately missing `usage` fields
and injected error statuses — without spending real credits. Point `Base URL` at
the mock server to use it.

## Testing

The project ships two test layers.

### Unit and integration tests

```bash
npm test
```

Runs `node --test tests/` against the pure modules in `src/js/core/` and the
higher-level modules — usage normalization, difference calculation, error
classification, masking, and statistics. Because the modules are UMD, the tests
`require()` the same files the browser loads; there is no separate test build.

### Live API smoke check

```bash
export ARM_BASE_URL="https://api.example.com/v1"
export ARM_API_KEY="sk-..."
export ARM_MODEL="your-model-name"
npm run test:live
```

`scripts/live-check.mjs` issues a real request against a real endpoint and
reports what came back. It is **not** part of `npm test` and does not run in CI,
because it needs credentials and consumes real quota. Use a small key and
conservative parameters.

### Manual verification checklist

The behaviours below need a real endpoint or a device and are verified by hand:

- A real request against an OpenAI-compatible endpoint, including `usage`
  parsing.
- A custom `Base URL`.
- An invalid API key (`401`).
- HTTP `429` handling.
- An endpoint that returns no `usage`.
- `Small-scale Verification` with conservative defaults.
- Consecutive repeat runs and their aggregation.
- The complete flow in Chinese.
- The complete flow in English.
- Runtime `zh-CN` ↔ `en-US` switching, confirming no data loss.
- Android launch and the core flow.

> This section describes how to run the tests. It deliberately makes no claim
> about how many tests exist or pass; run the commands above for current
> results.

## Roadmap

### v0.1 MVP

- OpenAI-compatible `Base URL` / API key / model configuration
- Model list retrieval with graceful degradation
- `Token Usage Test` and `Small-scale Verification` modes
- Full `usage` field capture with explicit "unknown" markers
- Before/after balance or quota comparison and discrepancy rate
- Repeat verification with aggregation
- Neutral result wording
- JSON and CSV report export
- Complete `zh-CN` / `en-US` internationalization
- Local API key storage and log masking
- Conservative defaults (3 requests, `max_tokens` 100, concurrency 1)
- WebCatX Android packaging

### v0.2 Multi-provider

- Named provider profiles with saved, switchable configurations
- Provider capability detection (which optional fields an endpoint actually
  returns)
- Additional request shapes beyond Chat Completions
- Side-by-side runs against two endpoints under identical parameters

### v0.3 Advanced Verification

- Scheduled and interval-based repeat verification
- Trend charts for discrepancy rate across runs
- Pricing-rule modeling: input/output tiers, cache pricing, reasoning tokens,
  multipliers, minimum billable units
- Statistical significance indicators over larger sample sizes
- Comparison of multiple prompts to detect prompt-dependent behaviour

### v1.0 Stable

- Frozen data formats with migration for exported reports
- Documented stability guarantees for the report schema
- Expanded automated coverage of the pure modules
- Accessibility and responsive-layout pass
- Published release APK

Roadmap items are intentions, not commitments, and may change.

## License

MIT — see [LICENSE](LICENSE).

Copyright (c) 2025 AI Relay Meter Contributors.
