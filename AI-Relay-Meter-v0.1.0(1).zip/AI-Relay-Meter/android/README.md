# Packaging AI Relay Meter as an Android APK

This directory documents how to package AI Relay Meter into an Android
application with **WebCatX**.

WebCatX wraps a static web project in a WebView and exposes native Android
capabilities to the page through the `window.webcat` bridge. Because this project
is plain HTML, CSS, and classic JavaScript with no bundler and no server-side
component, it packages cleanly and needs **no Android SDK, Gradle, or Java
toolchain**.

- Bridge API reference: [../docs/webcat-api.md](../docs/webcat-api.md)
- Bridge quick reference: [../docs/webcat-quick.md](../docs/webcat-quick.md)
- Project overview: [../README.md](../README.md) ·
  [../README.zh-CN.md](../README.zh-CN.md)

---

## Table of Contents

- [Prerequisites](#prerequisites)
- [Step 1 — Generate the Locale Bundles](#step-1--generate-the-locale-bundles)
- [Step 2 — Assemble the Packaging Directory](#step-2--assemble-the-packaging-directory)
- [Step 3 — Create the WebCatX Project](#step-3--create-the-webcatx-project)
- [Step 4 — Set the Start Page](#step-4--set-the-start-page)
- [Step 5 — Configure `appConfig.xlt`](#step-5--configure-appconfigxlt)
- [Step 6 — Declare Permissions](#step-6--declare-permissions)
- [Step 7 — Build the APK](#step-7--build-the-apk)
- [Step 8 — Test on a Device](#step-8--test-on-a-device)
- [Platform Constraints](#platform-constraints)
- [Troubleshooting](#troubleshooting)

---

## Prerequisites

- **Node.js 18+** on the build machine, to generate locale bundles.
- **WebCatX** installed, with an Android device or emulator available for
  testing.
- A release-ready application ID (reverse-DNS form, e.g. `com.example.airelaymeter`).

## Step 1 — Generate the Locale Bundles

From the project root:

```bash
npm run build:locales
```

This generates `locales/zh-CN.js` and `locales/en-US.js` from the corresponding
`.json` sources.

**Do not skip this step.** The packaged app loads its translations over `file://`
via classic `<script>` tags, which requires the generated `.js` bundles. If they
are missing, the app still launches but displays raw translation keys instead of
text. See [Platform Constraints](#platform-constraints) for why.

## Step 2 — Assemble the Packaging Directory

Create a clean directory containing only runtime files. The build does not need
`node_modules/`, `tests/`, or `scripts/`.

```bash
mkdir -p dist-android
cp -r index.html assets locales src dist-android/
```

The resulting layout, which is what WebCatX should point at:

```text
dist-android/
├── index.html            # application entry (start page)
├── assets/
│   └── appIcon.png       # launcher icon
├── locales/
│   ├── zh-CN.json        # canonical source (kept for reference)
│   ├── en-US.json
│   ├── zh-CN.js          # generated — REQUIRED at runtime
│   └── en-US.js          # generated — REQUIRED at runtime
└── src/
    ├── css/
    │   └── style.css
    └── js/
        ├── app.js
        ├── api.js
        ├── engine.js
        ├── verify.js
        ├── report.js
        ├── i18n.js
        ├── store.js
        └── core/
            ├── usage.js
            ├── diff.js
            ├── errors.js
            ├── mask.js
            └── stats.js
```

Do **not** include:

| Path | Reason |
| --- | --- |
| `node_modules/` | No runtime dependencies; the app is static |
| `tests/` | Development-only |
| `scripts/` | Node tooling; `.mjs` files are not used by the page |
| `docs/`, `demo/`, `android/` | Documentation and development aids |
| `.git/` | Not part of the application payload |

Place `appConfig.xlt` at the root of the packaging directory (alongside
`index.html`), since WebCatX reads it from the project root. See
[Step 5](#step-5--configure-appconfigxlt) for its contents.

## Step 3 — Create the WebCatX Project

1. Open WebCatX and create a new project.
2. Set the project directory to the assembled `dist-android/` folder from
   [Step 2](#step-2--assemble-the-packaging-directory).
3. Confirm that `index.html` and `appConfig.xlt` are both visible at the project
   root. If they are nested inside a subdirectory, the start page will not
   resolve.

## Step 4 — Set the Start Page

Set the start page to `index.html`.

In `appConfig.xlt` this is the `data.启动页面` field:

```json
"启动页面": "index.html"
```

The path is relative to the project root. AI Relay Meter is a single-page
application — there is no routing, no hash navigation, and no additional pages to
register. Leave `indexPages` empty.

## Step 5 — Configure `appConfig.xlt`

`appConfig.xlt` is the WebCatX packaging configuration. It is a JSON file placed
at the project root. The template below is adapted from the original project's
configuration and is the recommended starting point.

```json
{
  "appName": "AI Relay Meter",
  "appPackageName": "com.example.airelaymeter",
  "appVersionName": "0.1.0",
  "appVersionCode": 10000,
  "data": {
    "启用顶栏": true,
    "顶栏标题": "AI Relay Meter",
    "顶栏颜色": "#FF2C2E43",
    "横屏": false,
    "显示状态栏": true,
    "启用进度条": true,
    "进度条颜色": "#00000000",
    "支持打开外部应用": true,
    "提示打开外部应用": false,
    "启动页面": "index.html"
  },
  "indexPages": [],
  "extraHeaders": {}
}
```

### Field reference

#### Top-level fields

| Field | Type | Meaning | Notes |
| --- | --- | --- | --- |
| `appName` | string | Name shown on the Android launcher and in the app switcher | Keep it short enough not to be truncated |
| `appPackageName` | string | Android application ID | Must be globally unique and **must not change** between releases, or Android treats each build as a different app |
| `appVersionName` | string | Human-readable version shown to users | Match `package.json` and `CHANGELOG.md` |
| `appVersionCode` | integer | Monotonic build number | Must strictly increase for every published build; Android rejects upgrades with a lower or equal value |
| `indexPages` | array | Additional pages preloaded into the WebView | Leave empty for this single-page app |
| `extraHeaders` | object | Extra HTTP headers injected into page requests | Leave empty; no custom headers are needed |

#### `data` fields

| Field | Type | Meaning | Recommended value |
| --- | --- | --- | --- |
| `启用顶栏` | boolean | Show the native title bar above the WebView | `true` |
| `顶栏标题` | string | Title bar text | `AI Relay Meter` |
| `顶栏颜色` | string | Title bar color, `#AARRGGBB` | Match the app's header color, e.g. `#FF2C2E43` |
| `横屏` | boolean | Lock the app to landscape | `false` — the UI is mobile-first portrait |
| `显示状态栏` | boolean | Show the system status bar | `true` |
| `启用进度条` | boolean | Show the native page-loading progress bar | `true` |
| `进度条颜色` | string | Progress bar color, `#AARRGGBB` | `#00000000` renders it fully transparent, which is the original project's choice |
| `支持打开外部应用` | boolean | Allow the page to launch external apps (browser, dialer, deep links) | `true` — needed if you use `webcat.browser.open` for provider documentation |
| `提示打开外部应用` | boolean | Ask for confirmation before leaving the app | `false` |
| `启动页面` | string | Entry page, relative to the project root | `index.html` |

### Versioning checklist

Before each release, bump all three of:

- `appVersionCode` in `appConfig.xlt` (integer, must increase)
- `appVersionName` in `appConfig.xlt`
- `version` in `package.json`

and add a matching entry to [`../CHANGELOG.md`](../CHANGELOG.md).

## Step 6 — Declare Permissions

The verification and token-testing flows need **only network access**, which the
WebView has by default. No runtime permission prompt is required for the core
functionality.

Add permissions only if you extend the app:

| Feature | Permission to declare | Bridge call |
| --- | --- | --- |
| Saving exports to a public folder | Storage / "All files access" | `webcat.ext.writeFile("root", ...)`, `webcat.media.saveToDownload(...)` |
| Writing exports to app-private storage | None | `webcat.fs.writeFile(...)` |

Notes:

- The default build keeps exports inside the app, so **no permissions are needed
  out of the box**.
- If you call a bridge capability whose permission was not declared at packaging
  time, the call returns a guiding error rather than crashing. Declaring the
  permission and rebuilding resolves it.
- Prefer app-private storage (`webcat.fs`) or the system share sheet
  (`webcat.share`) over broad storage permissions, so users are not asked to
  grant more access than the app needs.

## Step 7 — Build the APK

1. In WebCatX, open the build/package action for the project.
2. Confirm the start page and application ID are correct.
3. Run the build and wait for the APK to be produced.
4. Install it on a device:

```bash
adb install -r app-release.apk
```

Or transfer the APK to the device and open it, allowing installation from
unknown sources if prompted.

Keep the signing key safe. Android requires all future updates to be signed with
the same key; losing it means users must uninstall and reinstall to upgrade.

## Step 8 — Test on a Device

Work through this checklist on a real device. Items marked *(manual)* require a
live API endpoint or human judgement and cannot be automated.

### Launch and rendering

- [ ] The app launches and renders the main screen — no blank page, no raw
      translation keys.
- [ ] The header is not overlapped by, and does not leave a gap below, the status
      bar.
- [ ] The layout is usable in portrait, with the language switcher reachable in
      the top-right corner.

### Configuration and persistence

- [ ] `Base URL`, `API Key`, and `Model` can be entered and are still present
      after restarting the app.
- [ ] **Get Models** succeeds against a provider that supports `GET /models`.
- [ ] **Get Models** against a provider without `/models` shows a readable
      message, and manual model entry still works.
- [ ] The API key field renders masked, not as plain text.

### Test modes

- [ ] *(manual)* A `Token Usage Test` completes and reports per-request latency
      and token counts.
- [ ] *(manual)* A `Small-scale Verification` run completes with the conservative
      defaults (3 requests, `max_tokens` 100, concurrency 1).
- [ ] *(manual)* **Stop Test** aborts an in-flight run promptly, and the partial
      results remain visible.

### Verification output

- [ ] *(manual)* The verification panel shows API usage, account usage,
      difference, and discrepancy rate when balance data is available.
- [ ] *(manual)* Manual before/after balance entry works when the provider
      exposes no balance endpoint.
- [ ] *(manual)* When balance data is missing, the app states that full
      verification is not possible instead of estimating.
- [ ] *(manual)* The outcome wording is one of the three neutral statements.

### Internationalization

- [ ] Switching to Chinese re-renders the whole UI, including errors and report
      headings.
- [ ] Switching back to English works.
- [ ] *(manual)* Switching language **during** a running test does not stop the
      test or lose any data.
- [ ] The language choice survives an app restart.

### Error handling

- [ ] *(manual)* A deliberately wrong API key produces a readable `401` message
      and does not crash or blank the app.
- [ ] *(manual)* A rate-limited endpoint produces a readable `429` message.
- [ ] *(manual)* An endpoint that returns no `usage` shows
      "No Token Usage returned by the API" rather than invented numbers.
- [ ] *(manual)* Airplane mode produces a readable network error rather than a
      crash.

### Export

- [ ] JSON export produces a file that opens and parses.
- [ ] CSV export produces a file that opens in a spreadsheet.
- [ ] Exported files contain **no** cleartext API key.

### Android integration

- [ ] The app icon appears correctly on the launcher.
- [ ] The app survives backgrounding and returning to the foreground.
- [ ] The back button behaves sensibly and does not exit mid-test without
      warning.

## Platform Constraints

Two consequences of loading the page from `file://` inside a WebView shape this
project. Both are documented in detail in
[../docs/ARCHITECTURE.md](../docs/ARCHITECTURE.md).

### Classic scripts, not ES modules

A page loaded from `file://` is treated as an opaque origin, so the WebView
blocks `type="module"` script loads under its CORS policy. AI Relay Meter
therefore uses **UMD-style classic scripts** throughout `src/js/`, loaded with
plain `<script src>` tags. This is why the packaging directory must contain the
`src/js/` tree exactly as it appears in the repository — do not attempt to
convert the modules to ESM or to bundle them.

### Generated locale bundles

For the same reason, `fetch("locales/zh-CN.json")` is blocked from `file://`.
Locale data is therefore delivered as executable JavaScript that assigns
`window.ARM_LOCALES`. This is why [Step 1](#step-1--generate-the-locale-bundles)
is mandatory.

### Network requests from `file://`

API requests originate from an opaque origin. Providers that reject browser or
unknown origins will fail with a network error even though the endpoint is
reachable. Two options:

1. **Use the WebView fetch path** and confirm the provider allows it.
2. **Route through the native bridge.** WebCatX exposes
   `webcat.network.request` — a native HTTP client with no CORS restriction:

   ```js
   // No CORS: runs natively, not from the page origin.
   const r = await webcat.network.request({
     method: "POST",
     url: baseUrl + "/chat/completions",
     headers: {
       "Content-Type": "application/json",
       "Authorization": "Bearer " + apiKey
     },
     body: JSON.stringify(payload)
   });
   // r => { ok, status, body }
   ```

   This is the intended extension point for providers that block browser
   origins. See [../docs/webcat-api.md](../docs/webcat-api.md). Note that
   streaming (SSE) is not available through this path, so it is best used for
   non-streaming requests.

### File exports

Triggering a download from a `file://` page does not behave like it does over
HTTP. If the browser download path produces no file on device, use the bridge:

```js
// App-private storage (no permission required)
await webcat.fs.writeFile("reports/session.json", json);

// Public Downloads folder (requires storage permission)
await webcat.media.saveToDownload("arm-report.json", json);

// Hand the file to another app
await webcat.share.text(json);
```

### Status bar spacing

WebCatX already handles status-bar and navigation-bar insets automatically. Do
**not** add compensating padding to the header. Padding is only needed if you
explicitly enable immersion with `webcat.statusBar.setAdaptive(true)`, and even
then the reported `height` is in device pixels, so divide by `density` before
applying it in CSS.

### `window.webcat` availability

The bridge is injected asynchronously and may arrive after the `load` event. Poll
for it before first use:

```js
function whenWebcatReady(cb) {
  if (window.webcat) return cb(window.webcat);
  var n = 0, t = setInterval(function () {
    if (window.webcat) { clearInterval(t); cb(window.webcat); }
    else if (++n > 120) { clearInterval(t); console.warn("webcat not injected"); }
  }, 50); // ~6 seconds max
}
```

Do not assume `window.webcat` exists at the top of a script. Core functionality
does not depend on the bridge, so the app remains fully usable in a plain
browser and in the Android WebView without it.

## Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| Blank page on launch | `index.html` not at the project root, or wrong start page | Confirm `启动页面` is `index.html` and the file sits at the project root |
| Raw keys like `config.baseUrl` shown instead of text | Locale `.js` bundles missing | Run `npm run build:locales` and re-copy `locales/` into the packaging directory |
| Page loads but nothing is interactive | A `src/js/` file failed to load | Verify the full `src/js/` tree was copied, including `core/` |
| Network error on every request, endpoint works elsewhere | Provider rejects the `file://` origin | Route through `webcat.network.request`, or test in a browser over `npm run serve` |
| Export produces no file | `file://` download restriction | Use `webcat.fs.writeFile` or `webcat.media.saveToDownload` |
| Header hidden behind the status bar | Extra padding applied, or immersion enabled | Remove the compensating padding; let WebCatX handle insets |
| Extra whitespace at the top of the page | Compensating padding for the status bar | Remove it — WebCatX already avoids the inset |
| App installs as a second app after an update | `appPackageName` changed between builds | Keep the application ID identical across all releases |
| "App not installed" when updating | `appVersionCode` not increased, or signing key changed | Increase `appVersionCode`; always sign with the same key |
| Bridge calls return an error about undeclared permission | Capability not checked at packaging time | Declare the permission in WebCatX and rebuild |
| Settings lost after restart | `localStorage` restricted in the WebView | Expected fallback; configuration is best-effort in restricted origins |

## Related Documentation

- [../README.md](../README.md) — project overview (English)
- [../README.zh-CN.md](../README.zh-CN.md) — project overview (Chinese)
- [../docs/ARCHITECTURE.md](../docs/ARCHITECTURE.md) — module design, data flow,
  and the `file://` constraints in full
- [../docs/webcat-api.md](../docs/webcat-api.md) — complete bridge API reference
- [../docs/webcat-quick.md](../docs/webcat-quick.md) — bridge quick reference
