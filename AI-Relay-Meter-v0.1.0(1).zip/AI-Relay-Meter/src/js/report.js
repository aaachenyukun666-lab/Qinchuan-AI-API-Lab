/**
 * AI Relay Meter - report builder and exporters
 *
 * Produces one report object from a test session, then serialises it to JSON or
 * CSV. Every value that could not be obtained stays null and carries a
 * completeness flag, so a reader can tell "zero" apart from "unknown".
 *
 * The API key is NEVER included in any export.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./core/mask.js'),
      require('./core/stats.js')
    );
  } else {
    root.ARM = root.ARM || {};
    root.ARM.report = factory(root.ARM.mask, root.ARM.stats);
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (maskLib, statsLib) {
  'use strict';

  var REPORT_VERSION = '1.0';
  var SCHEMA_ID = 'ai-relay-meter/report';

  /** Round to fixed decimals without turning null into 0. */
  function roundTo(value, decimals) {
    if (typeof value !== 'number' || !isFinite(value)) return null;
    var f = Math.pow(10, decimals === undefined ? 4 : decimals);
    return Math.round(value * f) / f;
  }

  function isNum(v) {
    return typeof v === 'number' && isFinite(v);
  }

  /** Map a flat engine record onto the report's request shape. */
  function mapRecord(record) {
    return {
      index: record.index,
      startedAt: record.startedAt,
      model: record.model,
      requestId: record.requestId || null,
      status: record.status,
      latencyMs: record.latencyMs,
      ok: !!record.ok,
      errorCode: record.errorCode || null,
      errorMessage: record.errorMessage || null,
      promptTokens: record.promptTokens,
      completionTokens: record.completionTokens,
      totalTokens: record.totalTokens,
      cachedTokens: record.cachedTokens,
      reasoningTokens: record.reasoningTokens,
      usageSource: record.usageSource,
      usageDerived: !!record.usageDerived,
      hasUsage: !!record.hasUsage,
      streamed: !!record.streamed
    };
  }

  /** Honest notes about what is missing and why. */
  function completenessNotes(summary, requestStats) {
    var notes = [];
    if (summary.stoppedEarly) {
      notes.push('The run stopped before completing all planned requests (' +
        (summary.stopReason || 'unknown reason') + ').');
    }
    if (summary.fatalCode) {
      notes.push('A non-retryable error occurred: ' + summary.fatalCode + '.');
    }
    if (requestStats.totalRequests > 0 &&
        requestStats.requestsWithUsage < requestStats.totalRequests) {
      notes.push(
        'The API did not return Token Usage for ' +
        (requestStats.totalRequests - requestStats.requestsWithUsage) +
        ' of ' + requestStats.totalRequests +
        ' requests. Totals cover only requests that reported usage.'
      );
    }
    if (summary.totalTokens === null) {
      notes.push('No Token Usage was reported, so no token total is available.');
    }
    return notes;
  }

  /** Notes for verification reports: what could not be verified, and why. */
  function verificationNotes(session, roundRecords) {
    var notes = [];
    var missing = roundRecords.filter(function (r) { return r.accountTokens === null; });
    if (missing.length) {
      notes.push(
        'Account usage was unavailable for ' + missing.length + ' of ' +
        roundRecords.length + ' rounds (no balance API and no manual entry), ' +
        'so the token difference could not be computed for those rounds.'
      );
    }
    if (!session.dataComplete) {
      notes.push('Not every round produced a complete, comparable measurement.');
    }
    if (session.repeat > 1) {
      notes.push(
        'Repeated testing shows whether a difference is stable. The tool does ' +
        'not draw a conclusion from a single observation.'
      );
    }
    return notes;
  }

  /** Report for a Token Usage Test run. */
  function buildUsageReport(session, opts) {
    var summary = session.summary || {};
    var records = session.records || [];
    var requestStats = summary.requestStats || statsLib.summarizeRequests(records);

    return {
      schema: SCHEMA_ID,
      reportVersion: REPORT_VERSION,
      generatedAt: opts.generatedAt || new Date().toISOString(),
      locale: opts.locale || 'en-US',
      mode: 'usage',
      tool: { name: 'AI Relay Meter', version: '0.1.0' },

      configuration: {
        baseUrl: summary.baseUrl || null,
        model: summary.model || null,
        requests: summary.requests || null,
        maxTokens: summary.maxTokens || null,
        concurrency: summary.concurrency || null,
        stream: !!summary.stream,
        prompt: summary.prompt || null,
        // No key, no key fragment, no hash: the report is safe to share.
        apiKey: '[not included]'
      },

      timing: {
        startedAt: summary.startedAt || null,
        endedAt: summary.endedAt || null,
        durationMs: summary.durationMs || null
      },

      totals: {
        totalRequests: requestStats.totalRequests,
        successCount: requestStats.successCount,
        failureCount: requestStats.failureCount,
        requestsWithUsage: requestStats.requestsWithUsage,
        requestsWithoutUsage: requestStats.requestsWithoutUsage,
        promptTokens: requestStats.promptTokens.sum,
        completionTokens: requestStats.completionTokens.sum,
        totalTokens: summary.totalTokens,
        cachedTokens: requestStats.cachedTokens.sum,
        reasoningTokens: requestStats.reasoningTokens.sum
      },

      statistics: {
        totalTokens: requestStats.totalTokens,
        latencyMs: requestStats.latencyMs,
        promptTokens: requestStats.promptTokens,
        completionTokens: requestStats.completionTokens
      },

      errors: requestStats.errorCodeCounts,

      completeness: {
        complete: !!summary.dataComplete,
        stoppedEarly: !!summary.stoppedEarly,
        stopReason: summary.stopReason || null,
        fatalCode: summary.fatalCode || null,
        usageReportedForAllRequests:
          requestStats.requestsWithUsage === requestStats.totalRequests &&
          requestStats.totalRequests > 0,
        notes: completenessNotes(summary, requestStats)
      },

      requests: records.map(mapRecord)
    };
  }

  /** Report for a Small-scale Verification run (possibly repeated). */
  function buildVerificationReport(session, opts) {
    var rounds = session.rounds || [];
    var roundRecords = session.roundRecords || [];
    var requestStats = session.requestStats || statsLib.summarizeRequests([]);
    var firstOk = rounds.filter(function (r) { return r && r.ok; })[0];
    var config = (firstOk && firstOk.config) || {};

    return {
      schema: SCHEMA_ID,
      reportVersion: REPORT_VERSION,
      generatedAt: opts.generatedAt || new Date().toISOString(),
      locale: opts.locale || 'en-US',
      mode: 'verification',
      tool: { name: 'AI Relay Meter', version: '0.1.0' },

      configuration: {
        baseUrl: config.baseUrl || null,
        model: config.model || null,
        requestsPerRound: config.requests || null,
        maxTokens: config.maxTokens || null,
        concurrency: config.concurrency || null,
        stream: !!config.stream,
        repeat: session.repeat || null,
        accountUnit: config.accountUnit || 'currency',
        tolerancePercent: isNum(opts.tolerancePercent) ? opts.tolerancePercent : null,
        apiKey: '[not included]'
      },

      result: {
        status: session.status,
        conclusionKey: session.conclusionKey,
        /** Neutral wording only. The tool measures; it does not adjudicate. */
        statement:
          session.status === 'normal'
            ? 'No significant usage discrepancy detected.'
            : session.status === 'discrepancy'
              ? 'A usage or billing discrepancy was detected. Repeated testing is recommended.'
              : 'Insufficient data for full verification.',
        weightedDiscrepancyRate: roundTo(session.weightedDiscrepancyRate, 4),
        stability: session.stats ? session.stats.stability : 'unknown'
      },

      verification: {
        apiReportedTokens: session.stats ? session.stats.apiTokens.sum : null,
        accountUsage: session.stats ? session.stats.accountTokens.sum : null,
        accountUnit: config.accountUnit || 'currency',
        meanApiTokens: session.stats ? roundTo(session.stats.apiTokens.mean, 4) : null,
        meanAccountUsage: session.stats ? roundTo(session.stats.accountTokens.mean, 4) : null,
        meanDiscrepancyRate: session.stats ? roundTo(session.stats.discrepancyRate.mean, 4) : null,
        minDiscrepancyRate: session.stats ? roundTo(session.stats.discrepancyRate.min, 4) : null,
        maxDiscrepancyRate: session.stats ? roundTo(session.stats.discrepancyRate.max, 4) : null,
        stdevDiscrepancyRate: session.stats ? roundTo(session.stats.discrepancyRate.stdev, 4) : null,
        roundsWithCompleteData: session.stats ? session.stats.roundsWithCompleteData : 0
      },

      rounds: rounds.map(function (round) {
        if (!round || !round.ok) {
          return {
            roundIndex: round ? round.roundIndex : null,
            ok: false,
            error: round ? round.error : null
          };
        }
        return {
          roundIndex: round.roundIndex,
          ok: true,
          apiTokens: round.apiTokens,
          observedApiTokens: round.observedApiTokens,
          accountTokens: round.accountTokens,
          balanceBefore: round.balance.before.amount,
          balanceAfter: round.balance.after.amount,
          balanceSource: {
            before: round.balance.before.source,
            after: round.balance.after.source
          },
          deltaAvailable: round.balance.deltaAvailable,
          tokenDifference: round.analysis.token.diff.difference,
          tokenDiscrepancyRate: roundTo(round.analysis.token.diff.discrepancyRate, 4),
          theoreticalCost: round.costs.theoreticalCost,
          actualCost: round.analysis.cost.diff.actualCost,
          costDifference: round.analysis.cost.diff.difference,
          costDiscrepancyRate: roundTo(round.analysis.cost.diff.discrepancyRate, 4),
          status: round.analysis.status,
          requests: {
            total: round.summary.requests,
            completed: round.summary.completedRequests,
            success: round.summary.requestStats.successCount,
            failure: round.summary.requestStats.failureCount
          },
          completeness: {
            complete: !!round.summary.dataComplete,
            stoppedEarly: !!round.summary.stoppedEarly,
            stopReason: round.summary.stopReason || null
          }
        };
      }),

      totals: {
        totalRequests: requestStats.totalRequests,
        successCount: requestStats.successCount,
        failureCount: requestStats.failureCount,
        requestsWithUsage: requestStats.requestsWithUsage,
        promptTokens: requestStats.promptTokens.sum,
        completionTokens: requestStats.completionTokens.sum,
        totalTokens: requestStats.totalTokens.sum
      },

      statistics: {
        totalTokens: requestStats.totalTokens,
        latencyMs: requestStats.latencyMs,
        promptTokens: requestStats.promptTokens,
        completionTokens: requestStats.completionTokens
      },

      errors: requestStats.errorCodeCounts,

      completeness: {
        complete: !!session.dataComplete,
        roundsCompleted: roundRecords.length,
        roundsPlanned: session.repeat || null,
        tokenLayerAvailable: roundRecords.some(function (r) { return r.apiTokens !== null; }),
        accountLayerAvailable: roundRecords.some(function (r) { return r.accountTokens !== null; }),
        notes: verificationNotes(session, roundRecords)
      },

      requests: collectRecords(rounds).map(mapRecord)
    };
  }

  function collectRecords(rounds) {
    var out = [];
    (rounds || []).forEach(function (r) {
      if (r && r.ok && r.records) {
        r.records.forEach(function (rec) { out.push(rec); });
      }
    });
    return out;
  }

  /** JSON export. Pretty-printed so the file is diffable and reviewable. */
  function toJSON(report, pretty) {
    return JSON.stringify(report, null, pretty === false ? 0 : 2);
  }

  /**
   * CSV export: a metadata section, an optional rounds table, then one row per
   * request. CRLF endings keep Excel happy; RFC 4180 escaping throughout.
   */
  function toCSV(report) {
    var rows = [];
    var CRLF = '\r\n';

    function meta(key, value) {
      rows.push([key, value === undefined || value === null ? '' : value]);
    }

    meta('schema', report.schema);
    meta('reportVersion', report.reportVersion);
    meta('generatedAt', report.generatedAt);
    meta('mode', report.mode);
    meta('baseUrl', report.configuration.baseUrl);
    meta('model', report.configuration.model);
    meta('apiKey', '[not included]');
    meta('repeat', report.configuration.repeat);
    meta('accountUnit', report.configuration.accountUnit);
    meta('resultStatus', report.result ? report.result.status : '');
    meta('resultStatement', report.result ? report.result.statement : '');
    meta('totalTokens', report.totals.totalTokens);
    meta('apiReportedTokens', report.verification ? report.verification.apiReportedTokens : '');
    meta('accountUsage', report.verification ? report.verification.accountUsage : '');
    meta('meanDiscrepancyRate', report.verification ? report.verification.meanDiscrepancyRate : '');
    meta('dataComplete', report.completeness.complete);

    if (report.completeness.notes && report.completeness.notes.length) {
      report.completeness.notes.forEach(function (n, i) {
        meta('note' + (i + 1), n);
      });
    }

    rows.push([]);

    if (report.mode === 'verification' && report.rounds) {
      rows.push(['[rounds]']);
      rows.push([
        'round', 'apiTokens', 'accountUsage', 'tokenDifference',
        'tokenDiscrepancyRate', 'theoreticalCost', 'actualCost',
        'costDifference', 'costDiscrepancyRate', 'status'
      ]);
      report.rounds.forEach(function (r) {
        rows.push([
          r.roundIndex, r.apiTokens, r.accountTokens, r.tokenDifference,
          r.tokenDiscrepancyRate, r.theoreticalCost, r.actualCost,
          r.costDifference, r.costDiscrepancyRate, r.status
        ]);
      });
      rows.push([]);
    }

    rows.push(['[requests]']);
    rows.push([
      'index', 'startedAt', 'model', 'requestId', 'httpStatus', 'latencyMs',
      'ok', 'errorCode', 'errorMessage', 'promptTokens', 'completionTokens',
      'totalTokens', 'cachedTokens', 'reasoningTokens', 'usageSource',
      'usageDerived', 'hasUsage', 'streamed'
    ]);
    (report.requests || []).forEach(function (r) {
      rows.push([
        r.index, r.startedAt, r.model, r.requestId, r.status, r.latencyMs,
        r.ok, r.errorCode, r.errorMessage, r.promptTokens, r.completionTokens,
        r.totalTokens, r.cachedTokens, r.reasoningTokens, r.usageSource,
        r.usageDerived, r.hasUsage, r.streamed
      ]);
    });

    return rows.map(function (row) {
      return row.map(csvCell).join(',');
    }).join(CRLF) + CRLF;
  }

  /** RFC 4180 escaping. */
  function csvCell(value) {
    if (value === undefined || value === null) return '';
    var s = String(value);
    if (/[",\r\n]/.test(s)) {
      return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  }

  /** e.g. ai-relay-meter-verification-20250102-150405.json */
  function suggestFilename(report, ext) {
    var d = new Date(report.generatedAt || Date.now());
    function p(n) { return ('0' + n).slice(-2); }
    var stamp = d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) +
      '-' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
    return 'ai-relay-meter-' + report.mode + '-' + stamp + '.' + (ext || 'json');
  }

  /** Safety net: refuse to export anything that looks like it leaks a key. */
  function assertNoSecrets(serialized) {
    if (maskLib.looksUnmasked(serialized)) {
      throw new Error('Refusing to export: the report appears to contain an unmasked API key.');
    }
    return true;
  }

  /** Build the right report kind for a session. */
  function build(session, opts) {
    var o = opts || {};
    var s = session || {};
    return s.rounds ? buildVerificationReport(s, o) : buildUsageReport(s, o);
  }

  return {
    REPORT_VERSION: REPORT_VERSION,
    SCHEMA_ID: SCHEMA_ID,
    build: build,
    toJSON: toJSON,
    toCSV: toCSV,
    suggestFilename: suggestFilename,
    assertNoSecrets: assertNoSecrets,
    csvCell: csvCell
  };
});
