/**
 * AI Relay Meter - local persistence
 *
 * Stores configuration and the last report in localStorage so a reload does not
 * lose the user's setup. Everything stays on the device: nothing is uploaded.
 *
 * The API key is only written when the user explicitly opts in, and it is stored
 * under a separate key so it can be cleared on its own.
 *
 * Every access is wrapped: private-browsing modes and WebViews can throw on
 * localStorage, and that must never break the app.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.ARM = root.ARM || {};
    root.ARM.store = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var KEYS = {
    settings: 'arm.settings.v1',
    secret: 'arm.secret.v1',
    lastReport: 'arm.lastReport.v1'
  };

  /** Detect a usable localStorage once, at load time. */
  var available = (function () {
    try {
      if (typeof localStorage === 'undefined') return false;
      var probe = '__arm_probe__';
      localStorage.setItem(probe, '1');
      localStorage.removeItem(probe);
      return true;
    } catch (e) {
      return false;
    }
  })();

  function isAvailable() {
    return available;
  }

  function readRaw(key) {
    if (!available) return null;
    try {
      return localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  }

  function writeRaw(key, value) {
    if (!available) return false;
    try {
      localStorage.setItem(key, value);
      return true;
    } catch (e) {
      // Quota exceeded or storage disabled mid-session.
      return false;
    }
  }

  function removeRaw(key) {
    if (!available) return false;
    try {
      localStorage.removeItem(key);
      return true;
    } catch (e) {
      return false;
    }
  }

  function readJSON(key, fallback) {
    var raw = readRaw(key);
    if (!raw) return fallback;
    try {
      var parsed = JSON.parse(raw);
      return parsed === null || parsed === undefined ? fallback : parsed;
    } catch (e) {
      // Corrupt entry: drop it rather than crashing on every load.
      removeRaw(key);
      return fallback;
    }
  }

  function writeJSON(key, value) {
    try {
      return writeRaw(key, JSON.stringify(value));
    } catch (e) {
      return false;
    }
  }

  /** Non-secret settings: base URL, model, parameters, preferences. */
  var DEFAULT_SETTINGS = {
    baseUrl: 'https://api.deepseek.com/v1',
    model: '',
    mode: 'verification',
    requests: 3,
    maxTokens: 100,
    concurrency: 1,
    stream: false,
    timeoutMs: 120000,
    prompt: '',
    accountUnit: 'currency',
    repeat: 1,
    tolerancePercent: 1.0,
    priceInput: '',
    priceOutput: '',
    rememberKey: false
  };

  function loadSettings() {
    var stored = readJSON(KEYS.settings, {});
    var merged = {};
    Object.keys(DEFAULT_SETTINGS).forEach(function (k) {
      merged[k] = Object.prototype.hasOwnProperty.call(stored, k)
        ? stored[k]
        : DEFAULT_SETTINGS[k];
    });
    return merged;
  }

  function saveSettings(settings) {
    var safe = {};
    // Never let a key leak into the non-secret blob, even by accident.
    Object.keys(settings || {}).forEach(function (k) {
      if (/apikey|api_key|secret|token/i.test(k) && k !== 'rememberKey') return;
      safe[k] = settings[k];
    });
    return writeJSON(KEYS.settings, safe);
  }

  function loadApiKey() {
    var raw = readRaw(KEYS.secret);
    return raw ? raw : '';
  }

  function saveApiKey(key) {
    if (!key) return removeRaw(KEYS.secret);
    return writeRaw(KEYS.secret, String(key));
  }

  function clearApiKey() {
    return removeRaw(KEYS.secret);
  }

  /** Keep the last report so the user can still export after a reload. */
  function saveLastReport(report) {
    return writeJSON(KEYS.lastReport, report);
  }

  function loadLastReport() {
    return readJSON(KEYS.lastReport, null);
  }

  function clearAll() {
    Object.keys(KEYS).forEach(function (k) { removeRaw(KEYS[k]); });
  }

  return {
    KEYS: KEYS,
    DEFAULT_SETTINGS: DEFAULT_SETTINGS,
    isAvailable: isAvailable,
    loadSettings: loadSettings,
    saveSettings: saveSettings,
    loadApiKey: loadApiKey,
    saveApiKey: saveApiKey,
    clearApiKey: clearApiKey,
    saveLastReport: saveLastReport,
    loadLastReport: loadLastReport,
    clearAll: clearAll
  };
});
