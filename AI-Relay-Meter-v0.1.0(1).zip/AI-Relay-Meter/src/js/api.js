/**
 * AI Relay Meter - OpenAI-compatible API client
 *
 * Handles: model discovery, chat completions (buffered and streamed), and
 * best-effort balance probing.
 *
 * Nothing here is provider-specific. A relay that speaks the OpenAI wire format
 * works; a relay that does not is reported as an error, not worked around.
 *
 * The client never logs or returns the API key in clear text.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./core/usage.js'),
      require('./core/errors.js'),
      require('./core/mask.js')
    );
  } else {
    root.ARM = root.ARM || {};
    root.ARM.api = factory(root.ARM.usage, root.ARM.errors, root.ARM.mask);
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (usageLib, errorsLib, maskLib) {
  'use strict';

  var DEFAULT_TIMEOUT_MS = 120000;
  var MODELS_TIMEOUT_MS = 30000;

  /** Join a base URL and a path without producing a double slash. */
  function joinUrl(base, path) {
    var b = String(base || '').trim().replace(/\/+$/, '');
    var p = String(path || '').replace(/^\/+/, '');
    return b + '/' + p;
  }

  /** Accept `api.example.com` as well as `https://api.example.com/v1`. */
  function normalizeBaseUrl(input) {
    var s = String(input || '').trim();
    if (!s) return '';
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    return s.replace(/\/+$/, '');
  }

  /** Extract a human-readable message from an OpenAI-style error body. */
  function extractApiMessage(body) {
    if (!body) return '';
    if (typeof body === 'string') return body.slice(0, 300);
    if (body.error && body.error.message) return String(body.error.message).slice(0, 300);
    if (body.message) return String(body.message).slice(0, 300);
    if (body.detail) return String(body.detail).slice(0, 300);
    return '';
  }

  /**
   * fetch() with a hard timeout, using AbortController when available.
   *
   * The timeout is enforced by racing a timer, because some WebViews ignore
   * AbortController on in-flight requests.
   */
  function fetchWithTimeout(url, options, timeoutMs, externalSignal) {
    var controller = null;
    var hasAbort = typeof AbortController !== 'undefined';
    if (hasAbort) controller = new AbortController();

    var opts = {};
    Object.keys(options || {}).forEach(function (k) { opts[k] = options[k]; });
    if (controller) opts.signal = controller.signal;

    var timedOut = false;
    var timer = setTimeout(function () {
      timedOut = true;
      if (controller) { try { controller.abort(); } catch (e) { /* ignore */ } }
    }, timeoutMs);

    var onExternalAbort = function () {
      if (controller) { try { controller.abort(); } catch (e) { /* ignore */ } }
    };
    if (externalSignal && externalSignal.addEventListener) {
      externalSignal.addEventListener('abort', onExternalAbort);
    }

    var timeoutPromise = new Promise(function (_resolve, reject) {
      setTimeout(function () {
        if (timedOut) {
          var e = new Error('Request timeout after ' + timeoutMs + 'ms');
          e.name = 'TimeoutError';
          reject(e);
        }
      }, timeoutMs + 20);
    });

    return Promise.race([fetch(url, opts), timeoutPromise])
      .then(function (res) {
        clearTimeout(timer);
        return res;
      })
      .catch(function (err) {
        clearTimeout(timer);
        if (timedOut && (err.name === 'AbortError' || /abort/i.test(String(err.message)))) {
          var e = new Error('Request timeout after ' + timeoutMs + 'ms');
          e.name = 'TimeoutError';
          throw e;
        }
        throw err;
      })
      .then(function (res) {
        if (externalSignal && externalSignal.removeEventListener) {
          externalSignal.removeEventListener('abort', onExternalAbort);
        }
        return res;
      });
  }

  function buildHeaders(apiKey, extra) {
    var h = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    if (apiKey) h['Authorization'] = 'Bearer ' + apiKey;
    Object.keys(extra || {}).forEach(function (k) { h[k] = extra[k]; });
    return h;
  }

  /**
   * Read an error response body and classify it.
   * Always resolves: a failed body read must not mask the HTTP status.
   */
  function classifyResponse(res) {
    return res.text()
      .catch(function () { return ''; })
      .then(function (text) {
        var parsed = null;
        try { parsed = text ? JSON.parse(text) : null; } catch (e) { parsed = null; }
        var msg = extractApiMessage(parsed || text);
        var cls = errorsLib.fromStatus(res.status, msg);
        cls.bodySnippet = maskLib.scrubText(text ? text.slice(0, 500) : '');
        return cls;
      });
  }

  /**
   * GET /models
   *
   * Many relays do not implement this endpoint. A 404/405 here is a normal,
   * non-fatal condition: the caller falls back to manual model entry.
   */
  function listModels(config) {
    var cfg = config || {};
    var base = normalizeBaseUrl(cfg.baseUrl);
    var url = joinUrl(base, 'models');

    return fetchWithTimeout(url, {
      method: 'GET',
      headers: buildHeaders(cfg.apiKey, cfg.headers)
    }, cfg.timeoutMs || MODELS_TIMEOUT_MS, cfg.signal)
      .then(function (res) {
        if (!res.ok) {
          return classifyResponse(res).then(function (cls) {
            if (cls.status === 404 || cls.status === 405 || cls.status === 501) {
              cls.code = 'MODELS_UNSUPPORTED';
              cls.retryable = false;
              cls.fatal = false;
            }
            throw cls;
          });
        }
        return res.json().catch(function (e) {
          throw errorsLib.badJson(e && e.message);
        }).then(function (data) {
          var list = data && Array.isArray(data.data) ? data.data : [];
          var seen = {};
          var models = [];
          list.forEach(function (m) {
            var id = m && (m.id || m.name || m.model);
            if (id && !seen[id]) {
              seen[id] = true;
              models.push({ id: String(id), raw: m });
            }
          });
          return { ok: true, models: models, url: url };
        });
      })
      .catch(function (err) {
        if (err && err.code) throw err;
        throw errorsLib.fromException(err);
      });
  }

  /**
   * Build the request body for a chat completion.
   * Unknown/undefined fields are omitted so the relay sees a clean payload.
   */
  function buildChatBody(params) {
    var p = params || {};
    var body = {
      model: p.model,
      messages: p.messages || [{ role: 'user', content: 'Hello' }],
      max_tokens: p.maxTokens
    };
    if (p.temperature !== undefined && p.temperature !== null) body.temperature = p.temperature;
    if (p.stream) body.stream = true;
    if (p.topP !== undefined && p.topP !== null) body.top_p = p.topP;
    if (p.stream && p.streamOptions) body.stream_options = p.streamOptions;
    Object.keys(body).forEach(function (k) {
      if (body[k] === undefined || body[k] === null) delete body[k];
    });
    return body;
  }

  /**
   * Non-streaming chat completion.
   *
   * @returns {Promise<{ok:true, usage, text, status, latencyMs, requestId, raw}>}
   *          or rejects with a classified error object.
   */
  function chatCompletion(config, params) {
    var cfg = config || {};
    var url = joinUrl(normalizeBaseUrl(cfg.baseUrl), 'chat/completions');
    var body = buildChatBody(params);
    var started = Date.now();

    return fetchWithTimeout(url, {
      method: 'POST',
      headers: buildHeaders(cfg.apiKey, cfg.headers),
      body: JSON.stringify(body)
    }, cfg.timeoutMs || DEFAULT_TIMEOUT_MS, cfg.signal)
      .then(function (res) {
        var latencyMs = Date.now() - started;
        if (!res.ok) {
          return classifyResponse(res).then(function (cls) {
            cls.latencyMs = latencyMs;
            cls.url = url;
            throw cls;
          });
        }
        return res.text().then(function (text) {
          var data;
          try {
            data = text ? JSON.parse(text) : {};
          } catch (e) {
            throw errorsLib.badJson('Response was not valid JSON');
          }
          var normalized = usageLib.normalizeUsage(data.usage);
          var choice = data.choices && data.choices[0];
          var content = choice && choice.message ? choice.message.content : '';
          return {
            ok: true,
            status: res.status,
            latencyMs: latencyMs,
            url: url,
            model: data.model || body.model,
            requestId: res.headers && res.headers.get ? (res.headers.get('x-request-id') || '') : '',
            usage: normalized,
            text: typeof content === 'string' ? content : '',
            finishReason: choice ? choice.finish_reason : null,
            raw: data
          };
        });
      })
      .catch(function (err) {
        if (err && err.code) throw err;
        throw errorsLib.fromException(err);
      });
  }

  /**
   * Streaming chat completion (SSE).
   *
   * Reads the stream incrementally so the UI can show progress. The final usage
   * is taken from the last chunk that carries one — OpenAI sends it on the
   * final chunk when `stream_options.include_usage` is set, and several relays
   * always append it.
   *
   * If no usage arrives, `usage.hasUsage` is false. We do NOT estimate tokens
   * from character counts; the report marks the run as incomplete instead.
   *
   * @param {function} onDelta  called with (textDelta, accumulatedText)
   */
  function chatCompletionStream(config, params, onDelta) {
    var cfg = config || {};
    var url = joinUrl(normalizeBaseUrl(cfg.baseUrl), 'chat/completions');
    var p = {};
    Object.keys(params || {}).forEach(function (k) { p[k] = params[k]; });
    p.stream = true;
    if (!p.streamOptions) p.streamOptions = { include_usage: true };
    var body = buildChatBody(p);
    var started = Date.now();

    return fetchWithTimeout(url, {
      method: 'POST',
      headers: buildHeaders(cfg.apiKey, Object.assign({ Accept: 'text/event-stream' }, cfg.headers)),
      body: JSON.stringify(body)
    }, cfg.timeoutMs || DEFAULT_TIMEOUT_MS, cfg.signal)
      .then(function (res) {
        if (!res.ok) {
          return classifyResponse(res).then(function (cls) {
            cls.latencyMs = Date.now() - started;
            throw cls;
          });
        }
        if (!res.body || typeof res.body.getReader !== 'function') {
          // No streaming support in this runtime: fall back to a buffered read
          // and parse any SSE frames we find in the whole body.
          return res.text().then(function (text) {
            return parseSseText(text, onDelta, started, url, body.model, res);
          });
        }
        return readSseStream(res, onDelta, started, url, body.model);
      })
      .catch(function (err) {
        if (err && err.code) throw err;
        throw errorsLib.fromException(err);
      });
  }

  function readSseStream(res, onDelta, started, url, model) {
    var reader = res.body.getReader();
    var decoder = typeof TextDecoder !== 'undefined' ? new TextDecoder('utf-8') : null;
    var buffer = '';
    var accumulated = '';
    var lastUsage = null;
    var finishReason = null;
    var sawDone = false;

    function handleFrame(frame) {
      var lines = frame.split('\n');
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (!line || line.charAt(0) === ':') continue;
        if (line.indexOf('data:') !== 0) continue;
        var payload = line.slice(5).trim();
        if (payload === '[DONE]') { sawDone = true; continue; }
        var chunk;
        try { chunk = JSON.parse(payload); } catch (e) { continue; }
        if (chunk.usage) lastUsage = chunk.usage;
        var choice = chunk.choices && chunk.choices[0];
        if (choice) {
          if (choice.finish_reason) finishReason = choice.finish_reason;
          var delta = choice.delta || choice.message || {};
          if (typeof delta.content === 'string' && delta.content) {
            accumulated += delta.content;
            if (typeof onDelta === 'function') onDelta(delta.content, accumulated);
          }
        }
      }
    }

    function pump() {
      return reader.read().then(function (result) {
        if (result.done) {
          if (buffer.trim()) handleFrame(buffer);
          return finalize();
        }
        buffer += decoder ? decoder.decode(result.value, { stream: true }) : String(result.value);
        var idx;
        while ((idx = buffer.indexOf('\n\n')) >= 0) {
          var frame = buffer.slice(0, idx);
          buffer = buffer.slice(idx + 2);
          handleFrame(frame);
        }
        return pump();
      });
    }

    function finalize() {
      return {
        ok: true,
        status: res.status,
        latencyMs: Date.now() - started,
        url: url,
        model: model,
        requestId: res.headers && res.headers.get ? (res.headers.get('x-request-id') || '') : '',
        usage: usageLib.normalizeUsage(lastUsage),
        text: accumulated,
        finishReason: finishReason,
        streamed: true,
        sawDone: sawDone
      };
    }

    return pump();
  }

  /** Parse a complete SSE body that arrived as one string. */
  function parseSseText(text, onDelta, started, url, model, res) {
    var accumulated = '';
    var lastUsage = null;
    var finishReason = null;
    var sawDone = false;
    var frames = String(text || '').split('\n\n');

    frames.forEach(function (frame) {
      frame.split('\n').forEach(function (line) {
        line = line.trim();
        if (line.indexOf('data:') !== 0) return;
        var payload = line.slice(5).trim();
        if (payload === '[DONE]') { sawDone = true; return; }
        var chunk;
        try { chunk = JSON.parse(payload); } catch (e) { return; }
        if (chunk.usage) lastUsage = chunk.usage;
        var choice = chunk.choices && chunk.choices[0];
        if (choice) {
          if (choice.finish_reason) finishReason = choice.finish_reason;
          var delta = choice.delta || choice.message || {};
          if (typeof delta.content === 'string' && delta.content) {
            accumulated += delta.content;
            if (typeof onDelta === 'function') onDelta(delta.content, accumulated);
          }
        }
      });
    });

    return {
      ok: true,
      status: res.status,
      latencyMs: Date.now() - started,
      url: url,
      model: model,
      requestId: res.headers && res.headers.get ? (res.headers.get('x-request-id') || '') : '',
      usage: usageLib.normalizeUsage(lastUsage),
      text: accumulated,
      finishReason: finishReason,
      streamed: true,
      sawDone: sawDone
    };
  }

  /**
   * Best-effort balance probe.
   *
   * There is NO standard balance endpoint in the OpenAI-compatible spec, so
   * this tries a small set of commonly seen paths and treats every failure as
   * "not available". It never guesses a balance and never marks a probe failure
   * as a test failure.
   *
   * @returns {Promise<{available:boolean, amount:number|null, currency:string|null, source:string}>}
   */
  function probeBalance(config) {
    var cfg = config || {};
    var base = normalizeBaseUrl(cfg.baseUrl);
    var paths = cfg.balancePaths || ['user/balance', 'dashboard/billing/credit_grants', 'credits'];
    var available = { available: false, amount: null, currency: null, source: '' };

    function tryPath(i) {
      if (i >= paths.length) return Promise.resolve(available);
      var url = joinUrl(base, paths[i]);
      return fetchWithTimeout(url, {
        method: 'GET',
        headers: buildHeaders(cfg.apiKey, cfg.headers)
      }, 8000, cfg.signal)
        .then(function (res) {
          if (!res.ok) return null;
          return res.json().catch(function () { return null; });
        })
        .then(function (data) {
          var found = extractBalance(data);
          if (found) {
            return {
              available: true,
              amount: found.amount,
              currency: found.currency,
              source: paths[i],
              raw: data
            };
          }
          return tryPath(i + 1);
        })
        .catch(function () {
          return tryPath(i + 1);
        });
    }

    return tryPath(0);
  }

  /**
   * Pull a numeric balance out of the several shapes relays use.
   * Returns null when nothing recognisable is present — never a fabricated 0.
   */
  function extractBalance(data) {
    if (!data || typeof data !== 'object') return null;

    // DeepSeek: { balance_infos: [{ currency, total_balance }] }
    if (Array.isArray(data.balance_infos) && data.balance_infos.length) {
      var info = data.balance_infos[0];
      var amt = firstNumber(info, ['total_balance', 'balance', 'available_balance']);
      if (amt !== null) {
        return { amount: amt, currency: info.currency || null };
      }
    }

    var direct = firstNumber(data, [
      'total_balance', 'balance', 'available_balance', 'remaining',
      'credits', 'total_available', 'amount'
    ]);
    if (direct !== null) {
      return { amount: direct, currency: data.currency || data.unit || null };
    }

    if (data.data && typeof data.data === 'object') {
      var nested = firstNumber(data.data, ['total_balance', 'balance', 'available_balance', 'credits']);
      if (nested !== null) {
        return { amount: nested, currency: data.data.currency || null };
      }
    }

    return null;
  }

  function firstNumber(source, keys) {
    if (!source) return null;
    for (var i = 0; i < keys.length; i++) {
      var v = source[keys[i]];
      if (typeof v === 'number' && isFinite(v)) return v;
      if (typeof v === 'string' && v.trim() !== '' && isFinite(Number(v))) return Number(v);
    }
    return null;
  }

  return {
    DEFAULT_TIMEOUT_MS: DEFAULT_TIMEOUT_MS,
    normalizeBaseUrl: normalizeBaseUrl,
    joinUrl: joinUrl,
    buildChatBody: buildChatBody,
    listModels: listModels,
    chatCompletion: chatCompletion,
    chatCompletionStream: chatCompletionStream,
    probeBalance: probeBalance,
    extractBalance: extractBalance,
    extractApiMessage: extractApiMessage
  };
});
