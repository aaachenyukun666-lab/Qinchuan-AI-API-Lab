/**
 * AI Relay Meter - verification orchestration
 *
 * Small-scale Verification is the core feature: make a few real, cheap
 * requests, then compare what the API said it consumed against how much the
 * account actually moved.
 *
 * Honesty rules enforced here:
 *   - If a balance cannot be read and the user did not type one in, the round is
 *     reported as incomplete. No number is invented.
 *   - Token differences and cost differences stay in separate buckets.
 *   - Repetition produces statistics, not a verdict.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./api.js'),
      require('./engine.js'),
      require('./core/diff.js'),
      require('./core/stats.js')
    );
  } else {
    root.ARM = root.ARM || {};
    root.ARM.verify = factory(
      root.ARM.api, root.ARM.engine, root.ARM.diff, root.ARM.stats
    );
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (
  apiLib, engineLib, diffLib, statsLib
) {
  'use strict';

  /** Conservative defaults: 3 requests, 100 max tokens, no parallelism. */
  var VERIFICATION_PRESET = {
    mode: 'verification',
    requests: 3,
    maxTokens: 100,
    concurrency: 1,
    stream: false
  };

  var REPEAT_CHOICES = [1, 3, 5];
  var MAX_REPEAT = 20;

  function toNumberOrNull(v) {
    if (typeof v === 'number' && isFinite(v)) return v;
    if (typeof v === 'string' && v.trim() !== '' && isFinite(Number(v))) return Number(v);
    return null;
  }

  /**
   * Read the account balance before/after a test when the provider offers one.
   * Every failure resolves "unavailable"; probing never throws to the caller.
   */
  function readBalance(config) {
    if (!config || config.skipBalanceProbe) {
      return Promise.resolve({
        available: false, amount: null, currency: null, source: 'skipped'
      });
    }
    return apiLib.probeBalance(config).catch(function () {
      return { available: false, amount: null, currency: null, source: 'unavailable' };
    });
  }

  /**
   * Resolve the balance inputs for a round, honouring user-supplied values.
   *
   * Manual entry is the documented fallback when no balance API exists, so an
   * explicit user value always wins over a failed probe.
   *
   * @returns {{amount:number|null, source:string, currency:string|null, available:boolean}}
   */
  function resolveBalance(manualValue, probed, label) {
    var manual = toNumberOrNull(manualValue);
    if (manual !== null) {
      return { amount: manual, source: 'manual', currency: null, available: true };
    }
    if (probed && probed.available && toNumberOrNull(probed.amount) !== null) {
      return {
        amount: probed.amount,
        source: 'api:' + (probed.source || 'unknown'),
        currency: probed.currency || null,
        available: true
      };
    }
    return {
      amount: null,
      source: 'unavailable:' + (label || ''),
      currency: null,
      available: false
    };
  }

  /**
   * Run one verification round.
   *
   * @param {object} rawConfig  engine config plus:
   *   balanceBefore / balanceAfter   manual values (nullable)
   *   accountUnit                    'currency' | 'tokens'
   *   priceInput / priceOutput       optional per-1K-token prices
   *   tolerancePercent
   * @param {object} hooks      forwarded to the engine
   * @returns {Promise<object>} round result
   */
  function runRound(rawConfig, hooks) {
    var cfg = rawConfig || {};
    var h = hooks || {};
    var roundIndex = cfg.roundIndex || 1;

    return readBalance(cfg).then(function (beforeProbe) {
      var before = resolveBalance(cfg.balanceBefore, beforeProbe, 'before');

      return engineLib.run(cfg, h).then(function (runResult) {
        if (!runResult.ok) {
          return {
            ok: false,
            roundIndex: roundIndex,
            error: runResult.error,
            records: []
          };
        }

        return readBalance(cfg).then(function (afterProbe) {
          var after = resolveBalance(cfg.balanceAfter, afterProbe, 'after');
          return finalizeRound(cfg, runResult, before, after, roundIndex);
        });
      });
    });
  }

  function finalizeRound(cfg, runResult, before, after, roundIndex) {
    var summary = runResult.summary;
    var unit = cfg.accountUnit === 'tokens' ? 'tokens' : 'currency';

    // Only a complete run yields a comparable API-side figure. A partial run
    // cannot be matched against a full balance delta, so we keep the observed
    // total but refuse to certify it.
    var apiTokens = summary.dataComplete ? summary.totalTokens : null;
    var observedApiTokens = summary.totalTokens;

    var accountUsage = diffLib.computeAccountUsage(before.amount, after.amount, unit);
    var accountTokens = unit === 'tokens' ? accountUsage.value : null;

    var cost = computeCosts(cfg, summary);

    var analysis = diffLib.analyze({
      apiTokens: apiTokens,
      accountTokens: accountTokens,
      accountUnit: unit,
      theoreticalCost: cost.theoreticalCost,
      actualCost: unit === 'currency' ? accountUsage.value : null,
      tolerancePercent: cfg.tolerancePercent
    });

    var balanceDeltaAvailable =
      before.amount !== null && after.amount !== null;

    return {
      ok: true,
      roundIndex: roundIndex,
      config: {
        baseUrl: summary.baseUrl,
        model: summary.model,
        requests: summary.requests,
        maxTokens: summary.maxTokens,
        concurrency: summary.concurrency,
        stream: summary.stream,
        accountUnit: unit
      },
      records: runResult.records,
      summary: summary,
      balance: {
        before: before,
        after: after,
        deltaAvailable: balanceDeltaAvailable,
        delta: accountUsage.value,
        unit: unit
      },
      observedApiTokens: observedApiTokens,
      apiTokens: apiTokens,
      accountTokens: unit === 'currency' ? null : accountTokens,
      costs: cost,
      analysis: analysis,
      /**
       * One flat record per round so the report can build its table without
       * re-deriving anything.
       */
      roundRecord: {
        roundIndex: roundIndex,
        apiTokens: apiTokens,
        accountTokens: unit === 'tokens' ? accountUsage.value : null,
        discrepancyRate: analysis.token.diff.discrepancyRate,
        absoluteDifference: analysis.token.diff.absoluteDifference,
        requests: summary.requests,
        completedRequests: summary.completedRequests,
        successCount: summary.requestStats.successCount,
        failureCount: summary.requestStats.failureCount,
        balanceBefore: before.amount,
        balanceAfter: after.amount,
        accountDelta: accountUsage.value,
        unit: unit,
        theoreticalCost: cost.theoreticalCost,
        actualCost: unit === 'currency' ? accountUsage.value : null,
        status: analysis.status
      }
    };
  }

  /**
   * Theoretical cost from per-1K-token prices.
   *
   * Returns nulls when prices were not supplied: an unknown price must never be
   * treated as zero, which would report a fake 100% discrepancy.
   */
  function computeCosts(cfg, summary) {
    var priceIn = toNumberOrNull(cfg.priceInput);
    var priceOut = toNumberOrNull(cfg.priceOutput);
    var stats = summary.requestStats;

    if (priceIn === null && priceOut === null) {
      return {
        theoreticalCost: null,
        priceInput: priceIn,
        priceOutput: priceOut,
        available: false
      };
    }

    var promptTokens = stats.promptTokens.sum || 0;
    var completionTokens = stats.completionTokens.sum || 0;

    var cost = 0;
    var used = false;
    if (priceIn !== null && stats.promptTokens.count > 0) {
      cost += (promptTokens / 1000) * priceIn;
      used = true;
    }
    if (priceOut !== null && stats.completionTokens.count > 0) {
      cost += (completionTokens / 1000) * priceOut;
      used = true;
    }

    return {
      theoreticalCost: used ? cost : null,
      priceInput: priceIn,
      priceOutput: priceOut,
      available: used
    };
  }

  /**
   * Run the verification N times and aggregate.
   *
   * @param {object} rawConfig  same shape as runRound, plus `repeat`
   * @param {object} hooks      plus onRoundStart(i, total), onRoundDone(round, i, total)
   * @returns {Promise<object>} aggregated verification result
   */
  function runRepeated(rawConfig, hooks) {
    var h = hooks || {};
    var cfg = rawConfig || {};
    var repeat = toNumberOrNull(cfg.repeat);
    repeat = (repeat === null || repeat < 1) ? 1 : Math.min(Math.floor(repeat), MAX_REPEAT);

    var rounds = [];
    var roundRecords = [];

    function next(i) {
      if (i > repeat) return Promise.resolve();

      if (typeof h.onRoundStart === 'function') h.onRoundStart(i, repeat);

      var roundCfg = {};
      Object.keys(cfg).forEach(function (k) { roundCfg[k] = cfg[k]; });
      roundCfg.roundIndex = i;

      // Manual balance values describe ONE delta. Applying them to every round
      // would multiply the same deduction N times, so they are only honoured on
      // a single-round run.
      if (repeat > 1) {
        roundCfg.balanceBefore = null;
        roundCfg.balanceAfter = null;
      }

      return runRound(roundCfg, h).then(function (round) {
        rounds.push(round);
        if (round.ok) roundRecords.push(round.roundRecord);
        if (typeof h.onRoundDone === 'function') h.onRoundDone(round, i, repeat);
        return next(i + 1);
      });
    }

    return next(1).then(function () {
      return buildRepeatedResult(cfg, rounds, roundRecords, repeat);
    });
  }

  function buildRepeatedResult(cfg, rounds, roundRecords, repeat) {
    var stats = statsLib.summarizeRounds(roundRecords);
    var weighted = statsLib.weightedDiscrepancyRate(roundRecords);

    var okRounds = rounds.filter(function (r) { return r.ok; });
    var allRecords = [];
    okRounds.forEach(function (r) {
      (r.records || []).forEach(function (rec) { allRecords.push(rec); });
    });

    var requestStats = statsLib.summarizeRequests(allRecords);

    // The overall verdict follows the weakest complete layer, exactly as one
    // round does. No layer, no verdict — 'insufficient' is the honest answer.
    var statuses = roundRecords.map(function (r) { return r.status; });
    var overall;
    if (!statuses.length || statuses.indexOf('discrepancy') >= 0) {
      overall = statuses.indexOf('discrepancy') >= 0 ? 'discrepancy' : 'insufficient';
    } else if (statuses.indexOf('normal') >= 0 && statuses.indexOf('insufficient') < 0) {
      overall = 'normal';
    } else {
      overall = 'insufficient';
    }

    var conclusionKey =
      overall === 'discrepancy'
        ? 'result.discrepancy'
        : overall === 'normal'
          ? 'result.normal'
          : 'result.insufficient';

    return {
      ok: true,
      repeat: repeat,
      rounds: rounds,
      roundRecords: roundRecords,
      requestStats: requestStats,
      totalTokens: requestStats.totalTokens.sum,
      stats: stats,
      weightedDiscrepancyRate: weighted,
      status: overall,
      conclusionKey: conclusionKey,
      /**
       * True only when every round produced a complete, comparable measurement.
       */
      dataComplete:
        roundRecords.length === repeat &&
        roundRecords.every(function (r) {
          return r.apiTokens !== null && r.accountTokens !== null;
        }),
      totalRequests: requestStats.totalRequests,
      successCount: requestStats.successCount,
      failureCount: requestStats.failureCount
    };
  }

  return {
    VERIFICATION_PRESET: VERIFICATION_PRESET,
    REPEAT_CHOICES: REPEAT_CHOICES,
    runRound: runRound,
    runRepeated: runRepeated,
    readBalance: readBalance,
    resolveBalance: resolveBalance,
    computeCosts: computeCosts
  };
});
