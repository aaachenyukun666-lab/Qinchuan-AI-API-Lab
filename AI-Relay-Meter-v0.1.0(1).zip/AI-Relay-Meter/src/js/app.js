/**
 * AI Relay Meter - application controller
 *
 * Wires the DOM to the engine, verification layer and report builder.
 *
 * Two rules this file follows everywhere:
 *   1. A language switch re-renders labels only. All test state lives in
 *      `state` and is never cleared by a locale change.
 *   2. Every rendered value comes from a real response or user input. Unknown
 *      values render as the localised "N/A", never as 0.
 */
(function () {
  'use strict';

  var ARM = window.ARM || {};
  var i18n = ARM.i18n;
  var store = ARM.store;
  var api = ARM.api;
  var engine = ARM.engine;
  var verify = ARM.verify;
  var reportLib = ARM.report;

  var $ = function (id) { return document.getElementById(id); };

  /** All mutable application state. A locale change must not touch this. */
  var state = {
    mode: 'verification',
    running: false,
    abortRequested: false,
    session: null,       // last engine result
    verification: null,  // last verify.runRepeated result
    report: null,
    lastRecords: [],
    progress: { done: 0, total: 0 },
    advancedOpen: false
  };

  var els = {};

  function cacheEls() {
    [
      'baseUrl', 'apiKey', 'model', 'rememberKey', 'keyHint', 'modelChips',
      'modelStatus', 'btnGetModels', 'modePicker', 'requests', 'maxTokens',
      'concurrency', 'timeoutSec', 'prompt', 'stream', 'btnToggleAdvanced',
      'advanced', 'repeat', 'accountUnit', 'balanceBefore', 'balanceAfter',
      'priceInput', 'priceOutput', 'tolerance', 'btnTestOne', 'btnStart',
      'btnStop', 'btnReset', 'progressTrack', 'progressBar', 'statusLine',
      'cardLive', 'statTokens', 'statRequests', 'statSuccess', 'statFailed',
      'statLatency', 'statDuration', 'log', 'cardVerify', 'verdict',
      'verdictLabel', 'verdictText', 'verdictNote', 'vApiUsage', 'vAccountUsage',
      'vDifference', 'vRate', 'vTheoryCost', 'vActualCost', 'vCostDiff',
      'vStability', 'roundsWrap', 'roundsBody', 'btnViewReport', 'btnExportJSON',
      'btnExportCSV', 'btnCopyReport', 'reportStatus', 'cardRequests',
      'requestsBody', 'toast', 'storageWarning', 'langZh', 'langEn'
    ].forEach(function (id) { els[id] = $(id); });
  }

  // ============================================================== helpers ====

  function t(key, params) {
    return i18n.t(key, params);
  }

  function na() {
    return t('units.notAvailable');
  }

  function fmtInt(n) {
    if (typeof n !== 'number' || !isFinite(n)) return na();
    return n.toLocaleString(i18n.getLocale(), { maximumFractionDigits: 0 });
  }

  function fmtDec(n, decimals) {
    if (typeof n !== 'number' || !isFinite(n)) return na();
    return n.toLocaleString(i18n.getLocale(), {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });
  }

  function fmtPct(n) {
    if (typeof n !== 'number' || !isFinite(n)) return na();
    return fmtDec(n, 2) + ' %';
  }

  function fmtTokens(n) {
    if (typeof n !== 'number' || !isFinite(n)) return na();
    return fmtInt(n);
  }

  function fmtDuration(ms) {
    if (typeof ms !== 'number' || !isFinite(ms)) return na();
    if (ms < 1000) return Math.round(ms) + ' ' + t('units.ms');
    return fmtDec(ms / 1000, 2) + ' ' + t('units.s');
  }

  function setStatus(text, kind) {
    els.statusLine.textContent = text || '';
    els.statusLine.className = 'status-line' + (kind ? ' ' + kind : '');
  }

  function toast(message) {
    els.toast.textContent = message;
    els.toast.classList.add('show');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(function () {
      els.toast.classList.remove('show');
    }, 2400);
  }

  function log(message, kind) {
    if (!els.log) return;
    els.log.style.display = 'block';
    var span = document.createElement('span');
    span.className = kind ? 'l-' + kind : '';
    var d = new Date();
    var hh = ('0' + d.getHours()).slice(-2);
    var mm = ('0' + d.getMinutes()).slice(-2);
    var ss = ('0' + d.getSeconds()).slice(-2);
    span.textContent = '[' + hh + ':' + mm + ':' + ss + '] ' + message + '\n';
    els.log.appendChild(span);
    els.log.scrollTop = els.log.scrollHeight;
    while (els.log.childNodes.length > 150) {
      els.log.removeChild(els.log.firstChild);
    }
  }

  /** Localised text for an error code. */
  function errorText(code) {
    if (!code) return t('errors.unknown');
    return t(ARM.errors.messageKey(code));
  }

  // ========================================================== config =========

  function readConfig() {
    var timeoutSec = Number(els.timeoutSec.value);
    return {
      mode: state.mode,
      baseUrl: els.baseUrl.value,
      apiKey: els.apiKey.value,
      model: els.model.value,
      requests: Number(els.requests.value),
      maxTokens: Number(els.maxTokens.value),
      concurrency: Number(els.concurrency.value),
      timeoutMs: (isFinite(timeoutSec) ? timeoutSec : 120) * 1000,
      stream: !!els.stream.checked,
      prompt: els.prompt.value,
      repeat: Number(els.repeat.value) || 1,
      accountUnit: els.accountUnit.value,
      balanceBefore: els.balanceBefore.value,
      balanceAfter: els.balanceAfter.value,
      priceInput: els.priceInput.value,
      priceOutput: els.priceOutput.value,
      tolerancePercent: Number(els.tolerance.value)
    };
  }

  function applyConfigToForm(settings) {
    els.baseUrl.value = settings.baseUrl || '';
    els.model.value = settings.model || '';
    els.requests.value = settings.requests;
    els.maxTokens.value = settings.maxTokens;
    els.concurrency.value = settings.concurrency;
    els.timeoutSec.value = Math.round((settings.timeoutMs || 120000) / 1000);
    els.stream.checked = !!settings.stream;
    els.prompt.value = settings.prompt || '';
    els.repeat.value = String(settings.repeat || 1);
    els.accountUnit.value = settings.accountUnit || 'currency';
    els.tolerance.value = settings.tolerancePercent;
    els.priceInput.value = settings.priceInput || '';
    els.priceOutput.value = settings.priceOutput || '';
    els.rememberKey.checked = !!settings.rememberKey;

    setMode(settings.mode === 'usage' ? 'usage' : 'verification', false);

    if (settings.rememberKey) {
      var key = store.loadApiKey();
      if (key) els.apiKey.value = key;
    }
  }

  function persistConfig() {
    var cfg = readConfig();
    store.saveSettings({
      baseUrl: cfg.baseUrl,
      model: cfg.model,
      mode: cfg.mode,
      requests: cfg.requests,
      maxTokens: cfg.maxTokens,
      concurrency: cfg.concurrency,
      stream: cfg.stream,
      timeoutMs: cfg.timeoutMs,
      prompt: cfg.prompt,
      accountUnit: cfg.accountUnit,
      repeat: cfg.repeat,
      tolerancePercent: cfg.tolerancePercent,
      priceInput: cfg.priceInput,
      priceOutput: cfg.priceOutput,
      rememberKey: els.rememberKey.checked
    });

    if (els.rememberKey.checked && els.apiKey.value) {
      store.saveApiKey(els.apiKey.value);
    } else if (!els.rememberKey.checked) {
      store.clearApiKey();
    }
    renderKeyHint();
  }

  function renderKeyHint() {
    var key = els.apiKey.value;
    if (!key) {
      els.keyHint.textContent = '';
      return;
    }
    els.keyHint.textContent = ARM.mask.maskKey(key);
  }

  /** Switching mode swaps the conservative presets, keeping a custom prompt. */
  function setMode(mode, applyPreset) {
    state.mode = mode;
    Array.prototype.forEach.call(
      els.modePicker.querySelectorAll('.mode-option'),
      function (opt) {
        opt.classList.toggle('active', opt.getAttribute('data-mode') === mode);
      }
    );
    Array.prototype.forEach.call(
      els.modePicker.querySelectorAll('input[name="mode"]'),
      function (input) { input.checked = input.value === mode; }
    );

    if (applyPreset !== false) {
      var preset = mode === 'usage' ? engine.PRESETS.usage : engine.PRESETS.verification;
      els.requests.value = preset.requests;
      els.maxTokens.value = preset.maxTokens;
      els.concurrency.value = preset.concurrency;
      els.repeat.value = '1';
    }

    // Verification results only make sense in verification mode.
    els.cardVerify.classList.toggle('hidden', mode !== 'verification');
    renderActionButtons();
  }

  function renderActionButtons() {
    els.btnStart.classList.toggle('hidden', state.running);
    els.btnStop.classList.toggle('hidden', !state.running);
    els.btnReset.classList.toggle('hidden', state.running || !state.reportObj);
    els.btnTestOne.disabled = state.running;
    els.btnGetModels.disabled = state.running;
    els.btnStart.textContent = state.mode === 'usage'
      ? t('action.startTest')
      : t('action.runVerification');
  }

  // ======================================================= model list ========

  function fetchModels() {
    var baseUrl = els.baseUrl.value;
    var apiKey = els.apiKey.value;
    if (!baseUrl || !apiKey) {
      els.modelStatus.textContent = t('errors.required');
      els.modelStatus.className = 'hint';
      return;
    }

    els.btnGetModels.disabled = true;
    els.modelStatus.textContent = t('form.loadingModels');
    els.modelStatus.className = 'hint';
    els.modelChips.innerHTML = '';
    log('GET ' + api.joinUrl(api.normalizeBaseUrl(baseUrl), 'models'));

    api.listModels({ baseUrl: baseUrl, apiKey: apiKey, timeoutMs: 30000 })
      .then(function (result) {
        if (!result.models.length) {
          els.modelStatus.textContent = t('status.modelsUnsupported');
          return;
        }
        els.modelChips.innerHTML = '';
        result.models.forEach(function (m) {
          var chip = document.createElement('button');
          chip.type = 'button';
          chip.className = 'chip';
          chip.textContent = m.id;
          chip.setAttribute('title', m.id);
          chip.addEventListener('click', function () {
            els.model.value = m.id;
            Array.prototype.forEach.call(
              els.modelChips.querySelectorAll('.chip'),
              function (c) { c.classList.remove('active'); }
            );
            chip.classList.add('active');
            persistConfig();
          });
          els.modelChips.appendChild(chip);
        });
        if (!els.model.value) {
          els.model.value = result.models[0].id;
          els.modelChips.firstChild.classList.add('active');
          persistConfig();
        }
        els.modelStatus.textContent = t('status.modelsLoaded', { count: result.models.length });
        log(t('status.modelsLoaded', { count: result.models.length }), 'ok');
      })
      .catch(function (err) {
        var code = err && err.code ? err.code : 'UNKNOWN';
        els.modelStatus.textContent = errorText(code);
        els.modelStatus.className = 'hint';
        log(errorText(code), 'err');
      })
      .then(function () {
        els.btnGetModels.disabled = false;
      });
  }

  // ==================================================== single request =======

  function testOneRequest() {
    var raw = readConfig();
    var normalized = engine.normalizeConfig(raw);
    if (!normalized.ok) {
      markFieldError(normalized.field);
      setStatus(t('errors.required'), 'error');
      return;
    }
    clearFieldErrors();

    els.btnTestOne.disabled = true;
    els.btnTestOne.textContent = t('action.testing');
    setStatus(t('status.running'));

    var cfg = normalized.config;
    log('POST ' + api.joinUrl(cfg.baseUrl, 'chat/completions'));

    var request = cfg.stream
      ? api.chatCompletionStream(cfg, {
        model: cfg.model,
        messages: [{ role: 'user', content: cfg.prompt }],
        maxTokens: cfg.maxTokens,
        temperature: cfg.temperature
      }, function (_delta, accumulated) {
        log('stream: ' + accumulated.length + ' chars');
      })
      : api.chatCompletion(cfg, {
        model: cfg.model,
        messages: [{ role: 'user', content: cfg.prompt }],
        maxTokens: cfg.maxTokens,
        temperature: cfg.temperature
      });

    request
      .then(function (response) {
        var usage = response.usage;
        log('HTTP ' + response.status + ' · ' + response.latencyMs + ' ms', 'ok');
        log(ARM.usage.describeUsage(usage), usage.hasUsage ? 'ok' : 'warn');
        if (!usage.hasUsage) {
          setStatus(errorText('NO_USAGE'), 'warn');
        } else {
          setStatus(t('live.totalTokens') + ': ' + fmtTokens(usage.totalTokens), 'ok');
        }
      })
      .catch(function (err) {
        var code = err && err.code ? err.code : 'UNKNOWN';
        log('HTTP ' + (err.status || '—') + ' · ' + errorText(code), 'err');
        setStatus(errorText(code), 'error');
      })
      .then(function () {
        els.btnTestOne.disabled = state.running;
        els.btnTestOne.textContent = t('action.testRequest');
      });
  }

  function markFieldError(fieldId) {
    clearFieldErrors();
    var el = els[fieldId];
    if (el) el.setAttribute('aria-invalid', 'true');
  }

  function clearFieldErrors() {
    ['baseUrl', 'model', 'apiKey'].forEach(function (id) {
      if (els[id]) els[id].removeAttribute('aria-invalid');
    });
  }

  // ============================================================ run ==========

  function startTest() {
    if (state.running) return;

    var raw = readConfig();
    var normalized = engine.normalizeConfig(raw);
    if (!normalized.ok) {
      markFieldError(normalized.field);
      setStatus(t('errors.required'), 'error');
      return;
    }
    clearFieldErrors();
    persistConfig();

    var cfg = normalized.config;

    state.running = true;
    state.abortRequested = false;
    state.session = null;
    state.verification = null;
    state.reportObj = null;
    state.lastRecords = [];
    state.progressMeta = {
      done: 0,
      total: cfg.requests * (cfg.mode === 'verification' ? (Number(els.repeat.value) || 1) : 1)
    };

    els.cardLive.classList.remove('hidden');
    els.cardRequests.classList.remove('hidden');
    els.progressTrack.style.display = 'block';
    els.progressBar.style.width = '0%';
    els.requestsBody.innerHTML = '';
    els.log.innerHTML = '';
    els.reportStatus.textContent = '';
    resetLiveStats();
    renderActionButtons();
    setStatus(t('status.running'));

    var hooks = {
      onRecord: function (record) {
        state.lastRecords.push(record);
        appendRequestRow(record);
        updateLiveStats();
      },
      onProgress: function (p) {
        state.progressMeta.done = p.done;
        var total = state.progressMeta.total || p.total;
        els.statRequests.textContent = p.done + ' / ' + total;
        els.progressBar.style.width = (total ? (p.done / total) * 100 : 0) + '%';
      },
      onRoundStart: function (i, total) {
        if (total > 1) {
          setStatus(t('verification.roundOf', { index: i, total: total }));
          log('=== ' + t('verification.roundOf', { index: i, total: total }) + ' ===', 'info');
        }
      }
    };

    var runPromise;
    if (cfg.mode === 'usage') {
      runPromise = engine.run(cfg, hooks).then(function (result) {
        state.session = result;
        return result;
      });
    } else {
      runPromise = verify.runRepeated(cfg, hooks).then(function (result) {
        state.verification = result;
        return result;
      });
    }

    runPromise
      .then(function (result) {
        finishRun(result, cfg);
      })
      .catch(function (err) {
        setStatus(errorText(err && err.code ? err.code : 'UNKNOWN'), 'error');
        log(String(err && err.message ? err.message : err), 'err');
      })
      .then(function () {
        state.running = false;
        els.btnStop.textContent = t('action.stopTest');
        els.btnStop.disabled = false;
        renderActionButtons();
      });
  }

  function finishRun(result, cfg) {
    els.progressBar.style.width = '100%';

    var report = reportLib.build(result, {
      locale: i18n.getLocale(),
      tolerancePercent: cfg.tolerancePercent
    });
    state.reportObj = report;
    store.saveLastReport(report);

    updateLiveStats();
    renderReportSummary();
    if (cfg.mode === 'verification') {
      renderVerification();
    }

    if (state.abortRequested) {
      setStatus(t('status.stopped'), 'warn');
    } else {
      setStatus(t('status.finished'), 'ok');
    }
    log('===== ' + t('status.finished') + ' =====', 'info');
  }

  function stopTest() {
    if (!state.running) return;
    state.abortRequested = true;
    els.btnStop.disabled = true;
    els.btnStop.textContent = t('action.stopping');
    engine.abortActive();
    setStatus(t('status.stopped'), 'warn');
    els.btnStop.disabled = false;
  }

  // ======================================================== live stats =======

  function resetLiveStats() {
    els.statTokens.textContent = '0';
    els.statRequests.textContent = '0 / ' + state.progressMeta.total;
    els.statSuccess.textContent = '0';
    els.statFailed.textContent = '0';
    els.statLatency.textContent = na();
    els.statDuration.textContent = na();
  }

  function updateLiveStats() {
    var records = state.lastRecords;
    var success = 0;
    var failed = 0;
    var tokens = 0;
    var haveTokens = false;
    var latencies = [];

    records.forEach(function (r) {
      if (r.ok) {
        success++;
        if (typeof r.latencyMs === 'number') latencies.push(r.latencyMs);
        if (typeof r.totalTokens === 'number') {
          tokens += r.totalTokens;
          haveTokens = true;
        }
      } else {
        failed++;
      }
    });

    els.statTokens.textContent = haveTokens ? fmtTokens(tokens) : na();
    els.statSuccess.textContent = fmtInt(success);
    els.statFailed.textContent = fmtInt(failed);

    if (latencies.length) {
      var avg = latencies.reduce(function (a, b) { return a + b; }, 0) / latencies.length;
      els.statLatency.textContent = Math.round(avg) + ' ' + t('units.ms');
    } else {
      els.statLatency.textContent = na();
    }

    var first = records[0];
    if (first && first.startedAt) {
      els.statDuration.textContent =
        fmtDuration(Date.now() - new Date(first.startedAt).getTime());
    }
  }

  function appendRequestRow(record) {
    var tr = document.createElement('tr');

    function cell(text, className) {
      var td = document.createElement('td');
      if (className) td.className = className;
      td.textContent = text;
      tr.appendChild(td);
    }

    cell(String(record.index));
    cell(record.status ? String(record.status) : '—');
    cell(record.latencyMs === null ? '—' : String(record.latencyMs), 'num');
    cell(record.promptTokens === null ? '—' : fmtTokens(record.promptTokens), 'num');
    cell(record.completionTokens === null ? '—' : fmtTokens(record.completionTokens), 'num');
    cell(record.totalTokens === null ? '—' : fmtTokens(record.totalTokens), 'num');

    var td = document.createElement('td');
    var pill = document.createElement('span');
    if (record.ok && record.hasUsage) {
      pill.className = 'pill ok';
      pill.textContent = 'OK';
    } else if (record.ok && !record.hasUsage) {
      pill.className = 'pill warn';
      pill.textContent = t('live.noUsage');
    } else {
      pill.className = 'pill fail';
      pill.textContent = record.errorCode ? errorText(record.errorCode) : t('errors.unknown');
    }
    td.appendChild(pill);
    tr.appendChild(td);

    els.requestsBody.appendChild(tr);
  }

  // ====================================================== verification =======

  function renderVerification() {
    var v = state.verification;
    if (!v || !v.ok) return;

    els.cardVerify.classList.remove('hidden');

    var status = v.status || 'insufficient';
    els.verdict.className = 'verdict ' + status;
    els.verdictLabel.textContent = t('result.' + status + 'Short');
    els.verdictText.textContent = t('result.' + status);

    var notes = [];
    if (!v.dataComplete) notes.push(t('verification.noBalanceApi'));
    if (v.repeat > 1) {
      notes.push(t('result.toleranceNote', {
        percent: fmtDec(Number(els.tolerance.value) || 1, 1)
      }));
    }
    els.verdictNote.textContent = notes.join(' ');

    var stats = v.stats || {};
    var lastRound = (v.rounds || []).filter(function (r) { return r.ok; }).slice(-1)[0];

    // API tokens: prefer the aggregate across rounds, fall back to the last round.
    var apiTotal = stats.apiTokens && stats.apiTokens.sum !== null
      ? stats.apiTokens.sum
      : (lastRound ? lastRound.apiTokens : null);
    var accountTotal = stats.accountTokens && stats.accountTokens.sum !== null
      ? stats.accountTokens.sum
      : (lastRound ? lastRound.accountTokens : null);

    els.vApiUsage.textContent = fmtTokens(apiTotal);

    var unitLabel = lastRound && lastRound.balance && lastRound.balance.unit === 'tokens'
      ? t('form.unitTokens')
      : t('form.unitCurrency');
    els.vAccountUsage.textContent = accountTotal === null
      ? na()
      : fmtDec(accountTotal, 4) + ' ' + unitLabel;

    var diff = (apiTotal !== null && accountTotal !== null &&
      lastRound && lastRound.balance && lastRound.balance.unit === 'tokens')
      ? accountTotal - apiTotal
      : null;
    els.vDifference.textContent = diff === null ? na() : fmtInt(diff);

    var rate = (v.weightedDiscrepancyRate !== null && v.weightedDiscrepancyRate !== undefined)
      ? v.weightedDiscrepancyRate
      : (stats.discrepancyRate ? stats.discrepancyRate.mean : null);
    els.vRate.textContent = fmtPct(rate);

    els.vTheoryCost.textContent =
      lastRound && lastRound.costs && lastRound.costs.theoreticalCost !== null
        ? fmtDec(lastRound.costs.theoreticalCost, 6)
        : na();
    els.vActualCost.textContent =
      lastRound && lastRound.analysis && lastRound.analysis.cost.diff.actualCost !== null
        ? fmtDec(lastRound.analysis.cost.diff.actualCost, 6)
        : na();
    els.vCostDiff.textContent =
      lastRound && lastRound.analysis && lastRound.analysis.cost.diff.difference !== null
        ? fmtDec(lastRound.analysis.cost.diff.difference, 6)
        : na();

    var stability = stats.stability || 'unknown';
    els.vStability.textContent = t('verification.stability' +
      stability.charAt(0).toUpperCase() + stability.slice(1));

    renderRoundsTable(v);
  }

  function renderRoundsTable(v) {
    var records = v.roundRecords || [];
    if (records.length < 2) {
      els.roundsWrap.classList.add('hidden');
      return;
    }
    els.roundsWrap.classList.remove('hidden');
    els.roundsBody.innerHTML = '';

    records.forEach(function (r) {
      var tr = document.createElement('tr');
      function cell(text, className) {
        var td = document.createElement('td');
        if (className) td.className = className;
        td.textContent = text;
        tr.appendChild(td);
      }
      cell(String(r.roundIndex));
      cell(fmtTokens(r.apiTokens), 'num');
      cell(r.accountTokens === null ? na() : fmtDec(r.accountTokens, 4), 'num');
      cell(r.absoluteDifference === null ? na() : fmtInt(r.absoluteDifference), 'num');
      cell(fmtPct(r.discrepancyRate), 'num');
      els.roundsBody.appendChild(tr);
    });
  }

  // ============================================================= report ======

  function renderReportSummary() {
    if (!state.reportObj) {
      els.reportStatus.textContent = t('report.noReport');
      return;
    }
    var r = state.reportObj;
    var complete = r.completeness.complete
      ? t('report.complete')
      : t('report.incomplete');
    els.reportStatus.textContent =
      t('report.generatedAt') + ': ' +
      new Date(r.generatedAt).toLocaleString(i18n.getLocale()) +
      ' · ' + t('report.completeness') + ': ' + complete;
    renderActionButtons();
  }

  function viewReport() {
    if (!state.reportObj) {
      toast(t('report.noReport'));
      return;
    }
    var text = reportLib.toJSON(state.reportObj, true);
    var win = window.open('', '_blank');
    if (win && win.document) {
      win.document.title = t('report.title');
      var pre = win.document.createElement('pre');
      pre.style.cssText =
        'white-space:pre-wrap;word-break:break-word;' +
        'font:12px/1.6 ui-monospace,Menlo,monospace;padding:16px;margin:0';
      pre.textContent = text;
      win.document.body.style.margin = '0';
      win.document.body.appendChild(pre);
    } else {
      // Popup blocked: fall back to the clipboard so the user still gets it.
      copyText(text).then(function () { toast(t('report.copied')); });
    }
  }

  function exportReport(ext) {
    if (!state.reportObj) {
      toast(t('report.noReport'));
      return;
    }
    var content;
    try {
      content = ext === 'csv'
        ? reportLib.toCSV(state.reportObj)
        : reportLib.toJSON(state.reportObj, true);
      reportLib.assertNoSecrets(content);
    } catch (err) {
      els.reportStatus.textContent = t('errors.exportFailed', { reason: err.message });
      return;
    }

    var filename = reportLib.suggestFilename(state.reportObj, ext);
    var mime = ext === 'csv' ? 'text/csv;charset=utf-8' : 'application/json;charset=utf-8';

    downloadFile(content, filename, mime);
    els.reportStatus.textContent = t('report.downloadStarted', { filename: filename });
  }

  function downloadFile(content, filename, mime) {
    var blob = new Blob([content], { type: mime });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 1000);
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).catch(function () {
        return legacyCopy(text);
      });
    }
    return Promise.resolve(legacyCopy(text));
  }

  function legacyCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) { /* best effort */ }
    document.body.removeChild(ta);
  }

  function copyReport() {
    if (!state.reportObj) {
      toast(t('report.noReport'));
      return;
    }
    copyText(reportLib.toJSON(state.reportObj, true)).then(function () {
      toast(t('report.copied'));
    });
  }

  // ============================================================ language =====

  function renderLocale() {
    i18n.applyTo(document);
    els.langZh.classList.toggle('active', i18n.getLocale() === 'zh-CN');
    els.langEn.classList.toggle('active', i18n.getLocale() === 'en-US');
    els.btnToggleAdvanced.textContent = state.advancedOpen
      ? t('action.hideAdvanced')
      : t('action.showAdvanced');
    renderActionButtons();
    renderKeyHint();
    renderReportSummary();
    // Re-render results so units and labels follow the language, while the
    // measured numbers stay exactly as recorded.
    if (state.verification) renderVerification();
    if (state.lastRecords.length) {
      els.requestsBody.innerHTML = '';
      state.lastRecords.forEach(appendRequestRow);
      updateLiveStats();
    }
  }

  function switchLocale(tag) {
    i18n.setLocale(tag);
    renderLocale();
    toast(t('status.languageChanged'));
  }

  // =============================================================== events ====

  function bindEvents() {
    els.btnGetModels.addEventListener('click', fetchModels);
    els.btnTestOne.addEventListener('click', testOneRequest);
    els.btnStart.addEventListener('click', startTest);
    els.btnStop.addEventListener('click', stopTest);
    els.btnReset.addEventListener('click', resetAll);
    els.btnViewReport.addEventListener('click', viewReport);
    els.btnExportJSON.addEventListener('click', function () { exportReport('json'); });
    els.btnExportCSV.addEventListener('click', function () { exportReport('csv'); });
    els.btnCopyReport.addEventListener('click', copyReport);

    els.langZh.addEventListener('click', function () { switchLocale('zh-CN'); });
    els.langEn.addEventListener('click', function () { switchLocale('en-US'); });

    els.btnToggleAdvanced.addEventListener('click', function () {
      state.advancedOpen = !state.advancedOpen;
      els.advanced.classList.toggle('hidden', !state.advancedOpen);
      els.btnToggleAdvanced.textContent = state.advancedOpen
        ? t('action.hideAdvanced')
        : t('action.showAdvanced');
    });

    Array.prototype.forEach.call(
      els.modePicker.querySelectorAll('input[name="mode"]'),
      function (input) {
        input.addEventListener('change', function () {
          setMode(input.value, true);
          persistConfig();
        });
      }
    );

    els.apiKey.addEventListener('input', renderKeyHint);
    els.rememberKey.addEventListener('change', persistConfig);

    ['baseUrl', 'model', 'requests', 'maxTokens', 'concurrency', 'timeoutSec',
      'prompt', 'stream', 'repeat', 'accountUnit', 'priceInput', 'priceOutput',
      'tolerance'].forEach(function (id) {
        var el = els[id];
        if (!el) return;
        el.addEventListener('change', persistConfig);
      });
  }

  function resetAll() {
    state.session = null;
    state.verification = null;
    state.reportObj = null;
    state.lastRecords = [];
    state.progressMeta = { done: 0, total: 0 };
    state.abortRequested = false;

    els.cardLive.classList.add('hidden');
    els.cardRequests.classList.add('hidden');
    els.cardVerify.classList.add('hidden');
    els.progressTrack.style.display = 'none';
    els.progressBar.style.width = '0%';
    els.log.innerHTML = '';
    els.log.style.display = 'none';
    els.requestsBody.innerHTML = '';
    els.roundsBody.innerHTML = '';
    els.roundsWrap.classList.add('hidden');
    els.reportStatus.textContent = '';
    resetLiveStats();
    setStatus(t('status.ready'));
    renderActionButtons();
  }

  // ================================================================= boot ====

  function boot() {
    cacheEls();
    bindEvents();

    i18n.init({ basePath: 'locales/' }).then(function () {
      applyConfigToForm(store.loadSettings());
      renderLocale();
      setStatus(t('status.ready'));

      if (!store.isAvailable()) {
        els.storageWarning.classList.remove('hidden');
      }

      // Restore the previous report so exports still work after a reload.
      var last = store.loadLastReport();
      if (last) {
        state.reportObj = last;
        renderReportSummary();
      }
      renderActionButtons();
    });

    i18n.subscribe(function () {
      // Language changed elsewhere: re-render without touching state.
      renderLocale();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  // Exposed for tests and for the Android shell to trigger actions.
  window.ARMApp = {
    state: state,
    startTest: startTest,
    stopTest: stopTest,
    resetAll: resetAll,
    exportReport: exportReport,
    switchLocale: switchLocale
  };
})();
