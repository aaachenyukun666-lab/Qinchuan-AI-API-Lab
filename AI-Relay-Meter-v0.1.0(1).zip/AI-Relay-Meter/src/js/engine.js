/**
 * AI Relay Meter - test engine
 *
 * Runs a batch of real API requests with bounded concurrency, records one
 * structured entry per request, and reports progress as it goes.
 *
 * Guarantees:
 *   - Every request in the batch is a real HTTP call. Nothing is simulated.
 *   - A fatal error (bad key, unknown model, no permission) stops the run
 *     immediately instead of repeating a request that cannot succeed.
 *   - Stopping is cooperative and immediate; in-flight requests are aborted.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./api.js'),
      require('./core/usage.js'),
      require('./core/errors.js'),
      require('./core/mask.js'),
      require('./core/stats.js')
    );
  } else {
    root.ARM = root.ARM || {};
    root.ARM.engine = factory(
      root.ARM.api, root.ARM.usage, root.ARM.errors, root.ARM.mask, root.ARM.stats
    );
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (
  apiLib, usageLib, errorsLib, maskLib, statsLib
) {
  'use strict';

  /**
   * Conservative defaults, per the specification: a user who just presses
   * "Start" must not burn a meaningful amount of quota.
   */
  var PRESETS = {
    verification: {
      id: 'verification',
      requests: 3,
      maxTokens: 100,
      concurrency: 1,
      temperature: 1.0,
      stream: false,
      timeoutMs: 120000,
      prompt: 'Reply with one short sentence about the weather.'
    },
    usage: {
      id: 'usage',
      requests: 5,
      maxTokens: 256,
      concurrency: 2,
      temperature: 1.0,
      stream: false,
      timeoutMs: 120000,
      prompt: 'Write a short paragraph about API observability.'
    }
  };

  /** Hard ceilings so a typo in a number field cannot start a runaway test. */
  var LIMITS = {
    requests: { min: 1, max: 500 },
    maxTokens: { min: 1, max: 32768 },
    concurrency: { min: 1, max: 16 },
    timeoutMs: { min: 5000, max: 1800000 }
  };

  function clamp(value, min, max, fallback) {
    var n = Number(value);
    if (!isFinite(n)) return fallback;
    n = Math.floor(n);
    if (n < min) return min;
    if (n > max) return max;
    return n;
  }

  /**
   * Validate and normalise a test configuration.
   * Returns {ok:true, config} or {ok:false, field, code} for the UI to localise.
   */
  function normalizeConfig(input) {
    var src = input || {};

    if (!src.baseUrl || !String(src.baseUrl).trim()) {
      return { ok: false, field: 'baseUrl', code: 'required' };
    }
    if (!src.model || !String(src.model).trim()) {
      return { ok: false, field: 'model', code: 'required' };
    }
    if (!src.apiKey || !String(src.apiKey).trim()) {
      return { ok: false, field: 'apiKey', code: 'required' };
    }

    var requests = clamp(src.requests, LIMITS.requests.min, LIMITS.requests.max, 3);
    var concurrency = clamp(src.concurrency, LIMITS.concurrency.min, LIMITS.concurrency.max, 1);

    // Concurrency above the request count is pointless and would leave workers
    // idle; clamping keeps the progress display honest.
    if (concurrency > requests) concurrency = requests;

    return {
      ok: true,
      config: {
        mode: src.mode === 'usage' ? 'usage' : 'verification',
        baseUrl: apiLib.normalizeBaseUrl(src.baseUrl),
        apiKey: String(src.apiKey).trim(),
        model: String(src.model).trim(),
        requests: requests,
        maxTokens: clamp(src.maxTokens, LIMITS.maxTokens.min, LIMITS.maxTokens.max, 100),
        concurrency: concurrency,
        temperature: typeof src.temperature === 'number' ? src.temperature : 1.0,
        stream: !!src.stream,
        timeoutMs: clamp(src.timeoutMs, LIMITS.timeoutMs.min, LIMITS.timeoutMs.max, 120000),
        prompt: String(src.prompt || PRESETS.verification.prompt),
        headers: src.headers || null
      }
    };
  }

  /**
   * One request -> one record. This record shape is the contract shared by the
   * engine, the report builder and the CSV exporter.
   *
   * @param {number} index 1-based request number
   */
  function makeRecord(index, model) {
    return {
      index: index,
      startedAt: new Date().toISOString(),
      model: model,
      requestId: '',
      status: 0,
      latencyMs: null,
      ok: false,
      errorCode: null,
      errorMessage: '',
      promptTokens: null,
      completionTokens: null,
      totalTokens: null,
      cachedTokens: null,
      reasoningTokens: null,
      usageSource: 'unavailable',
      usageDerived: false,
      hasUsage: false,
      textPreview: ''
    };
  }

  /** Flatten a successful API response into a record. */
  function applySuccess(record, response) {
    var usage = response.usage || usageLib.normalizeUsage(null);
    var accountable = usageLib.accountableTokens(usage);

    record.ok = true;
    record.status = response.status;
    record.latencyMs = response.latencyMs;
    record.requestId = response.requestId || '';
    record.hasUsage = !!usage.hasUsage;

    record.promptTokens = usage.promptTokens;
    record.completionTokens = usage.completionTokens;
    record.totalTokens = accountable.tokens;
    record.cachedTokens = usage.cachedTokens;
    record.reasoningTokens = usage.reasoningTokens;
    record.usageSource = accountable.source;
    record.usageDerived = accountable.derived;

    if (!usage.hasUsage) {
      // Explicitly flagged rather than filled with an estimate.
      record.errorCode = 'NO_USAGE';
      record.errorMessage = 'API did not return Token Usage';
    }

    if (response.text) {
      record.textPreview = maskLib.scrubText(String(response.text).slice(0, 200));
    }
    record.finishReason = response.finishReason || null;
    record.streamed = !!response.streamed;
    return record;
  }

  /** Flatten a classified API error into a record. */
  function applyFailure(record, classification) {
    record.ok = false;
    record.status = classification.status || 0;
    record.latencyMs = classification.latencyMs !== undefined ? classification.latencyMs : null;
    record.errorCode = classification.code || 'UNKNOWN';
    record.errorMessage = maskLib.scrubText(
      classification.apiMessage || classification.raw || ''
    );
    return record;
  }

  /**
   * The currently running session, if any.
   *
   * Only one session may run at a time: two concurrent runs would fight over
   * the same abort handle and double-count nothing useful. Keeping the handle
   * here lets the UI stop a run without reaching into engine internals.
   */
  var activeRun = null;

  /** Abort the active run, if there is one. @returns {boolean} */
  function abortActive() {
    if (!activeRun) return false;
    activeRun.stop('stopped');
    return true;
  }

  function hasActiveRun() {
    return !!activeRun;
  }

  /**
   * Run one test session.
   *
   * @param {object} rawConfig
   * @param {object} hooks
   *   onRecord(record)           - called once per finished request
   *   onProgress({done,total})   - called as requests settle
   *   onDelta(text, accumulated) - streaming text preview callback
   * @returns {Promise<object>} {ok, config, records, summary}
   */
  function run(rawConfig, hooks) {
    var h = hooks || {};
    var normalized = normalizeConfig(rawConfig);
    if (!normalized.ok) {
      return Promise.resolve({
        ok: false,
        error: normalized,
        records: [],
        summary: null
      });
    }

    var cfg = normalized.config;
    var abortController =
      (typeof AbortController !== 'undefined') ? new AbortController() : null;
    var state = {
      running: true,
      aborted: false,
      stopReason: null,
      nextIndex: 1,
      records: [],
      completed: 0,
      fatalCode: null
    };

    var startedAt = Date.now();

    function stop(reason) {
      if (!state.running) return;
      state.running = false;
      state.stopReason = reason || 'stopped';
      state.aborted = true;
      if (abortController) {
        try { abortController.abort(); } catch (e) { /* ignore */ }
      }
    }

    function callOnce(index) {
      var record = makeRecord(index, cfg.model);
      var params = {
        model: cfg.model,
        messages: [
          { role: 'system', content: 'You are a concise assistant.' },
          { role: 'user', content: cfg.prompt }
        ],
        maxTokens: cfg.maxTokens,
        temperature: cfg.temperature,
        stream: cfg.stream
      };

      var requestConfig = {
        baseUrl: cfg.baseUrl,
        apiKey: cfg.apiKey,
        headers: cfg.headers,
        timeoutMs: cfg.timeoutMs,
        signal: abortController ? abortController.signal : null
      };

      var promise = cfg.stream
        ? apiLib.chatCompletionStream(requestConfig, params, h.onDelta)
        : apiLib.chatCompletion(requestConfig, params);

      return promise
        .then(function (response) {
          return applySuccess(record, response);
        })
        .catch(function (err) {
          var classification = (err && err.code) ? err : errorsLib.fromException(err);
          if (state.aborted || classification.code === 'ABORTED') {
            // A request aborted by the user is not a failure of the relay.
            record.ok = false;
            record.errorCode = 'ABORTED';
            record.errorMessage = 'Aborted by user';
            record.aborted = true;
            return record;
          }
          applyFailure(record, classification);
          record.classification = classification;
          return record;
        });
    }

    function worker() {
      if (!state.running || state.nextIndex > cfg.requests) return Promise.resolve();

      var index = state.nextIndex++;
      return callOnce(index).then(function (record) {
        state.records.push(record);
        state.completed++;

        if (typeof h.onRecord === 'function') h.onRecord(record);
        if (typeof h.onProgress === 'function') {
          h.onProgress({ done: state.completed, total: cfg.requests });
        }

        // A fatal classification means retrying cannot help: stop the batch and
        // tell the user which condition was hit.
        if (record.classification && errorsLib.shouldAbortRun(record.classification)) {
          state.fatalCode = record.errorCode;
          stop('fatal');
          return Promise.resolve();
        }

        if (!state.running) return Promise.resolve();
        return worker();
      });
    }

    activeRun = { stop: stop };

    var workers = [];
    for (var i = 0; i < cfg.concurrency; i++) workers.push(worker());

    return Promise.all(workers).then(function () {
      if (activeRun && activeRun.stop === stop) activeRun = null;
      var endedAt = Date.now();
      var summary = buildSummary(cfg, state, startedAt, endedAt);
      return {
        ok: true,
        config: cfg,
        records: state.records,
        summary: summary
      };
    });
  }

  function buildSummary(cfg, state, startedAt, endedAt) {
    var requestStats = statsLib.summarizeRequests(state.records);
    var totalTokens = requestStats.totalTokens.sum;

    return {
      mode: cfg.mode,
      baseUrl: cfg.baseUrl,
      model: cfg.model,
      requests: cfg.requests,
      maxTokens: cfg.maxTokens,
      concurrency: cfg.concurrency,
      stream: cfg.stream,
      prompt: cfg.prompt,
      startedAt: new Date(startedAt).toISOString(),
      endedAt: new Date(endedAt).toISOString(),
      durationMs: endedAt - startedAt,
      completedRequests: state.completed,
      stoppedEarly: !!state.stopReason,
      stopReason: state.stopReason,
      fatalCode: state.fatalCode,
      requestStats: requestStats,
      totalTokens: totalTokens,
      /**
       * A run is only "complete" when every planned request finished AND the
       * API actually reported usage for all of them. Anything else is reported
       * as incomplete rather than quietly averaged.
       */
      dataComplete:
        state.completed === cfg.requests &&
        requestStats.requestsWithUsage === cfg.requests &&
        !state.stopReason
    };
  }

  return {
    PRESETS: PRESETS,
    LIMITS: LIMITS,
    normalizeConfig: normalizeConfig,
    run: run,
    abortActive: abortActive,
    hasActiveRun: hasActiveRun,
    makeRecord: makeRecord,
    applySuccess: applySuccess,
    applyFailure: applyFailure
  };
});
