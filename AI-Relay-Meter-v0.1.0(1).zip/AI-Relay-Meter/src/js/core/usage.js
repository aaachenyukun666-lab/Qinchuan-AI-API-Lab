/**
 * AI Relay Meter - usage normalisation
 *
 * Normalises the `usage` object returned by OpenAI-compatible APIs into one
 * stable internal shape. This module never invents numbers: every field is
 * either the value the API actually reported, or null. The raw payload is kept
 * under `raw` so a user can audit exactly what the server sent.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.ARM = root.ARM || {};
    root.ARM.usage = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function num(v) {
    return (typeof v === 'number' && isFinite(v)) ? v : null;
  }

  function obj(v) {
    return (v && typeof v === 'object' && !Array.isArray(v)) ? v : null;
  }

  function pick(source, keys) {
    if (!source) return null;
    for (var i = 0; i < keys.length; i++) {
      var n = num(source[keys[i]]);
      if (n !== null) return n;
    }
    return null;
  }

  /**
   * Cached tokens across the dialects seen in the wild:
   * OpenAI prompt_tokens_details.cached_tokens, DeepSeek prompt_cache_hit_tokens,
   * cache_read_input_tokens on some relays.
   */
  function extractCachedTokens(usage, promptDetails) {
    var direct = pick(usage, ['cached_tokens', 'prompt_cache_hit_tokens', 'cache_read_input_tokens']);
    if (direct !== null) return direct;
    return promptDetails ? pick(promptDetails, ['cached_tokens', 'cache_read_input_tokens']) : null;
  }

  /** Reasoning tokens: completion_tokens_details.reasoning_tokens, or top-level. */
  function extractReasoningTokens(usage, completionDetails) {
    var direct = pick(usage, ['reasoning_tokens']);
    if (direct !== null) return direct;
    return completionDetails ? pick(completionDetails, ['reasoning_tokens']) : null;
  }

  /** An empty usage block: present but carrying no usable accounting. */
  function emptyUsage(reason) {
    return {
      hasUsage: false,
      hasAnyTokenField: false,
      promptTokens: null,
      completionTokens: null,
      totalTokens: null,
      cachedTokens: null,
      reasoningTokens: null,
      promptTokensDetails: null,
      completionTokensDetails: null,
      reason: reason || 'missing',
      raw: null
    };
  }

  /**
   * Normalise a raw usage object.
   * `reason`: 'missing' | 'not_an_object' | 'no_token_fields' | 'ok'
   */
  function normalizeUsage(raw) {
    if (raw === undefined || raw === null) return emptyUsage('missing');
    var usage = obj(raw);
    if (!usage) return emptyUsage('not_an_object');

    var promptDetails = obj(usage.prompt_tokens_details);
    var completionDetails = obj(usage.completion_tokens_details);

    var promptTokens = pick(usage, ['prompt_tokens', 'input_tokens']);
    var completionTokens = pick(usage, ['completion_tokens', 'output_tokens']);
    var totalTokens = pick(usage, ['total_tokens']);

    if (promptTokens === null && completionTokens === null && totalTokens === null) {
      var out = emptyUsage('no_token_fields');
      out.raw = usage;
      out.promptTokensDetails = promptDetails;
      out.completionTokensDetails = completionDetails;
      return out;
    }

    return {
      hasUsage: true,
      hasAnyTokenField: true,
      promptTokens: promptTokens,
      completionTokens: completionTokens,
      totalTokens: totalTokens,
      cachedTokens: extractCachedTokens(usage, promptDetails),
      reasoningTokens: extractReasoningTokens(usage, completionDetails),
      promptTokensDetails: promptDetails,
      completionTokensDetails: completionDetails,
      reason: 'ok',
      raw: usage
    };
  }

  /**
   * The token figure used for accounting.
   * 1) total_tokens as reported; 2) prompt+completion when BOTH reported.
   * Derived totals are flagged so the report can label them honestly.
   */
  function accountableTokens(usage) {
    if (!usage || !usage.hasUsage) {
      return { tokens: null, source: 'unavailable', derived: false };
    }
    if (usage.totalTokens !== null) {
      return { tokens: usage.totalTokens, source: 'total_tokens', derived: false };
    }
    if (usage.promptTokens !== null && usage.completionTokens !== null) {
      return {
        tokens: usage.promptTokens + usage.completionTokens,
        source: 'prompt_plus_completion',
        derived: true
      };
    }
    if (usage.promptTokens !== null) {
      return { tokens: usage.promptTokens, source: 'prompt_tokens_only', derived: true };
    }
    if (usage.completionTokens !== null) {
      return { tokens: usage.completionTokens, source: 'completion_tokens_only', derived: true };
    }
    return { tokens: null, source: 'unavailable', derived: false };
  }

  /** Short human-readable summary for logs and CSV cells. */
  function describeUsage(usage) {
    if (!usage || !usage.hasUsage) return 'API did not return Token Usage';
    var parts = [];
    if (usage.promptTokens !== null) parts.push('prompt=' + usage.promptTokens);
    if (usage.completionTokens !== null) parts.push('completion=' + usage.completionTokens);
    if (usage.totalTokens !== null) parts.push('total=' + usage.totalTokens);
    if (usage.cachedTokens !== null) parts.push('cached=' + usage.cachedTokens);
    if (usage.reasoningTokens !== null) parts.push('reasoning=' + usage.reasoningTokens);
    return parts.length ? parts.join(' ') : 'API did not return Token Usage';
  }

  return {
    normalizeUsage: normalizeUsage,
    accountableTokens: accountableTokens,
    describeUsage: describeUsage,
    emptyUsage: emptyUsage
  };
});
