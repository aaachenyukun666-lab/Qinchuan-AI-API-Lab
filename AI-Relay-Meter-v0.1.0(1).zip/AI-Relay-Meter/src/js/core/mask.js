/**
 * AI Relay Meter - secret masking
 *
 * API keys must never appear in full inside logs, reports, exported files or
 * error messages. Every code path that prints a key goes through maskKey().
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.ARM = root.ARM || {};
    root.ARM.mask = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var KEEP_HEAD = 6;
  var KEEP_TAIL = 4;
  var MASK_CHAR = '*';
  var MASK_WIDTH = 12;

  function repeat(ch, n) {
    var out = '';
    for (var i = 0; i < n; i++) out += ch;
    return out;
  }

  /**
   * Mask a secret for display: sk-1234567890abcdef -> sk-123********abcd.
   * Short secrets are fully masked rather than partially revealed, because a
   * 10-character secret would otherwise leak most of itself.
   */
  function maskKey(secret) {
    if (secret === undefined || secret === null) return '';
    var s = String(secret);
    if (s.length === 0) return '';
    if (s.length <= KEEP_HEAD + KEEP_TAIL) {
      return repeat(MASK_CHAR, Math.max(4, s.length));
    }
    return s.slice(0, KEEP_HEAD) + repeat(MASK_CHAR, MASK_WIDTH) + s.slice(s.length - KEEP_TAIL);
  }

  /**
   * Best-effort scrubber for free-form text (error messages, echoed bodies).
   * Removes anything shaped like a bearer token or an sk- style key.
   */
  function scrubText(text) {
    if (text === undefined || text === null) return '';
    var s = String(text);
    s = s.replace(/Bearer\s+[A-Za-z0-9._\-]{8,}/gi, 'Bearer ' + repeat(MASK_CHAR, MASK_WIDTH));
    s = s.replace(/\bsk-[A-Za-z0-9._\-]{8,}/g, function (m) { return maskKey(m); });
    s = s.replace(
      /(["']?(?:api[_-]?key|apikey|authorization|access[_-]?token)["']?\s*[:=]\s*["'])([^"']{6,})(["'])/gi,
      function (_m, pre, secret, post) { return pre + maskKey(secret) + post; }
    );
    return s;
  }

  /** Headers safe to log: auth-bearing headers are replaced wholesale. */
  function safeHeaders(headers) {
    var out = {};
    if (!headers) return out;
    Object.keys(headers).forEach(function (k) {
      if (/^(authorization|api[-_]?key|x-api-key|proxy-authorization)$/i.test(k)) {
        out[k] = 'Bearer ' + repeat(MASK_CHAR, MASK_WIDTH);
      } else {
        out[k] = headers[k];
      }
    });
    return out;
  }

  /** True when the text still contains something that looks like a live key. */
  function looksUnmasked(text) {
    if (!text) return false;
    return /\bsk-[A-Za-z0-9._\-]{16,}/.test(String(text));
  }

  return {
    maskKey: maskKey,
    scrubText: scrubText,
    safeHeaders: safeHeaders,
    looksUnmasked: looksUnmasked
  };
});
