/**
 * AI Relay Meter - error classification
 *
 * Maps transport failures and HTTP status codes onto stable, translatable
 * error codes. The UI never shows a raw exception: it shows a code, and the
 * i18n layer turns that code into a sentence in the user's language.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.ARM = root.ARM || {};
    root.ARM.errors = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  /** code -> i18n key under `errors.*` */
  var CODES = {
    OK: 'ok',
    INVALID_KEY: 'invalidKey',
    FORBIDDEN: 'forbidden',
    NOT_FOUND: 'notFound',
    BAD_REQUEST: 'badRequest',
    RATE_LIMITED: 'rateLimited',
    INSUFFICIENT_QUOTA: 'insufficientQuota',
    SERVER_ERROR: 'serverError',
    BAD_GATEWAY: 'badGateway',
    TIMEOUT: 'timeout',
    ABORTED: 'aborted',
    NETWORK: 'network',
    CORS: 'cors',
    BAD_JSON: 'badJson',
    MODELS_UNSUPPORTED: 'modelsUnsupported',
    NO_USAGE: 'noUsage',
    UNKNOWN: 'unknown'
  };

  function isCode(c) {
    return Object.prototype.hasOwnProperty.call(CODES, c);
  }

  /** i18n key for a code, e.g. `errors.rateLimited`. */
  function messageKey(code) {
    return 'errors.' + (CODES[code] || CODES.UNKNOWN);
  }

  /**
   * Classify an HTTP status.
   * `fatal` means retrying cannot help (bad key, bad model, no permission).
   */
  function fromStatus(status, apiMessage) {
    var code = 'UNKNOWN';
    var retryable = false;
    var fatal = false;

    if (status === 400) {
      code = 'BAD_REQUEST'; fatal = true;
    } else if (status === 401) {
      code = 'INVALID_KEY'; fatal = true;
    } else if (status === 402) {
      code = 'INSUFFICIENT_QUOTA'; fatal = true;
    } else if (status === 403) {
      code = 'FORBIDDEN'; fatal = true;
    } else if (status === 404) {
      code = 'NOT_FOUND'; fatal = true;
    } else if (status === 408 || status === 504) {
      code = 'TIMEOUT'; retryable = true;
    } else if (status === 429) {
      code = 'RATE_LIMITED'; retryable = true;
    } else if (status === 502) {
      code = 'BAD_GATEWAY'; retryable = true;
    } else if (status >= 500) {
      code = 'SERVER_ERROR'; retryable = true;
    }

    return {
      code: code,
      status: status,
      retryable: retryable,
      fatal: fatal,
      apiMessage: apiMessage ? String(apiMessage) : ''
    };
  }

  /**
   * Classify a thrown value from fetch(). Browsers reveal almost nothing for
   * CORS failures, so a bare "Failed to fetch" is reported as CORS with a hint.
   */
  function fromException(err) {
    var raw = err && err.message ? String(err.message) : String(err || '');
    var name = err && err.name ? String(err.name) : '';
    var code = 'UNKNOWN';
    var retryable = true;

    if (name === 'AbortError' || /abort/i.test(raw)) {
      code = 'ABORTED'; retryable = false;
    } else if (/timeout|timed out/i.test(raw)) {
      code = 'TIMEOUT';
    } else if (/failed to fetch|networkerror|network request failed|load failed/i.test(raw)) {
      code = 'CORS';
    } else if (/dns|enotfound|getaddrinfo|name or service not known|econnrefused/i.test(raw)) {
      code = 'NETWORK';
    } else if (/json/i.test(raw) && /parse|unexpected/i.test(raw)) {
      code = 'BAD_JSON'; retryable = false;
    }

    return {
      code: code,
      status: 0,
      retryable: retryable,
      fatal: false,
      raw: raw
    };
  }

  /** A response body that was not valid JSON. */
  function badJson(detail) {
    return {
      code: 'BAD_JSON',
      status: 0,
      retryable: false,
      fatal: false,
      raw: detail ? String(detail) : ''
    };
  }

  /**
   * Whether a run should stop early. A fatal, non-retryable condition (bad key,
   * bad model, no permission) will not fix itself by trying again, so the
   * engine stops instead of burning requests. Rate limits and 5xx do not stop.
   */
  function shouldAbortRun(classification) {
    if (!classification) return false;
    if (classification.code === 'ABORTED') return true;
    return !!classification.fatal;
  }

  return {
    CODES: CODES,
    isCode: isCode,
    messageKey: messageKey,
    fromStatus: fromStatus,
    fromException: fromException,
    badJson: badJson,
    shouldAbortRun: shouldAbortRun
  };
});
