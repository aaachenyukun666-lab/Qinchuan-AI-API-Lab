/**
 * AI Relay Meter - run statistics
 *
 * Aggregates repeated tests. The purpose of repetition is to let a user see
 * whether a difference is stable; the program therefore reports the spread and
 * deliberately does not convert it into a final accusation.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.ARM = root.ARM || {};
    root.ARM.stats = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function isNum(v) {
    return typeof v === 'number' && isFinite(v);
  }

  function sum(arr) {
    var t = 0;
    for (var i = 0; i < arr.length; i++) t += arr[i];
    return t;
  }

  function mean(arr) {
    return arr.length ? sum(arr) / arr.length : null;
  }

  function median(arr) {
    if (!arr.length) return null;
    var s = arr.slice().sort(function (a, b) { return a - b; });
    var mid = Math.floor(s.length / 2);
    return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
  }

  /** Population standard deviation; null below two samples. */
  function stdev(arr) {
    if (arr.length < 2) return null;
    var m = mean(arr);
    var acc = 0;
    for (var i = 0; i < arr.length; i++) {
      var d = arr[i] - m;
      acc += d * d;
    }
    return Math.sqrt(acc / arr.length);
  }

  /** Descriptive statistics, or nulls when there is no data. */
  function describe(values) {
    var arr = (values || []).filter(isNum);
    if (!arr.length) {
      return {
        count: 0, sum: null, mean: null, median: null,
        min: null, max: null, stdev: null, range: null
      };
    }
    return {
      count: arr.length,
      sum: sum(arr),
      mean: mean(arr),
      median: median(arr),
      min: Math.min.apply(null, arr),
      max: Math.max.apply(null, arr),
      stdev: stdev(arr),
      range: Math.max.apply(null, arr) - Math.min.apply(null, arr)
    };
  }

  function field(records, key) {
    return (records || [])
      .map(function (r) { return r ? r[key] : null; })
      .filter(isNum);
  }

  function countBy(arr, keyFn) {
    var out = {};
    (arr || []).forEach(function (item) {
      var k = keyFn(item);
      out[k] = (out[k] || 0) + 1;
    });
    return out;
  }

  /**
   * Summarise a batch of per-request records (flat record shape).
   *
   * Only successful requests carrying real usage contribute to token figures.
   * Counting failures as zero tokens would drag every average down and make a
   * healthy relay look like it under-reports.
   */
  function summarizeRequests(records) {
    var all = records || [];
    var ok = all.filter(function (r) { return r && r.ok === true; });
    var withUsage = ok.filter(function (r) { return r.hasUsage === true; });

    return {
      totalRequests: all.length,
      successCount: ok.length,
      failureCount: all.length - ok.length,
      requestsWithUsage: withUsage.length,
      requestsWithoutUsage: ok.length - withUsage.length,

      promptTokens: describe(field(withUsage, 'promptTokens')),
      completionTokens: describe(field(withUsage, 'completionTokens')),
      totalTokens: describe(field(withUsage, 'totalTokens')),
      cachedTokens: describe(field(withUsage, 'cachedTokens')),
      reasoningTokens: describe(field(withUsage, 'reasoningTokens')),

      latencyMs: describe(field(ok, 'latencyMs')),
      httpStatusCounts: countBy(all, function (r) {
        return r && r.status ? String(r.status) : 'error';
      }),
      errorCodeCounts: countBy(
        all.filter(function (r) { return r && r.ok !== true; }),
        function (r) { return (r && r.errorCode) || 'UNKNOWN'; }
      )
    };
  }

  /**
   * Summarise repeated verification rounds.
   * Each round: {apiTokens, accountTokens, discrepancyRate}.
   * Exposes mean/min/max/stdev of the discrepancy rate so stability is visible.
   */
  function summarizeRounds(rounds) {
    var list = (rounds || []).filter(Boolean);

    var apiValues = list.map(function (r) { return r.apiTokens; }).filter(isNum);
    var accountValues = list.map(function (r) { return r.accountTokens; }).filter(isNum);
    var rateValues = list.map(function (r) { return r.discrepancyRate; }).filter(isNum);

    return {
      roundCount: list.length,
      roundsWithCompleteData: rateValues.length,
      apiTokens: describe(apiValues),
      accountTokens: describe(accountValues),
      discrepancyRate: describe(rateValues),
      /** Stability hint for the UI; 'unknown' means too few complete rounds. */
      stability: classifyStability(rateValues)
    };
  }

  function classifyStability(rates) {
    if (rates.length < 2) return 'unknown';
    var sd = stdev(rates);
    if (sd === null) return 'unknown';
    if (sd < 0.5) return 'stable';
    if (sd < 3) return 'moderate';
    return 'unstable';
  }

  /**
   * Weighted mean discrepancy rate: total absolute difference over total API
   * tokens. Preferred over the arithmetic mean of per-round rates because a
   * round with tiny token counts would otherwise dominate the average.
   */
  function weightedDiscrepancyRate(rounds) {
    var list = (rounds || []).filter(Boolean);
    var totalApi = 0;
    var totalAbsDiff = 0;
    var usable = 0;

    list.forEach(function (r) {
      if (isNum(r.apiTokens) && isNum(r.accountTokens) && r.apiTokens > 0) {
        totalApi += r.apiTokens;
        totalAbsDiff += Math.abs(r.accountTokens - r.apiTokens);
        usable++;
      }
    });

    if (!usable || totalApi === 0) return null;
    return (totalAbsDiff / totalApi) * 100;
  }

  return {
    describe: describe,
    summarizeRequests: summarizeRequests,
    summarizeRounds: summarizeRounds,
    weightedDiscrepancyRate: weightedDiscrepancyRate,
    countBy: countBy,
    classifyStability: classifyStability
  };
});
