/**
 * AI Relay Meter - discrepancy analysis
 *
 * Compares what the API reported consuming against what the account actually
 * lost, at the token layer and -- separately -- at the cost layer.
 *
 * Rules taken from the specification:
 *   - Token counts and money are never merged into one number.
 *   - Missing inputs produce status 'insufficient', never a guess.
 *   - The conclusion wording is neutral: this tool measures, it does not accuse.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.ARM = root.ARM || {};
    root.ARM.diff = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  /** Verification outcomes; keys map to `result.*` in the locale bundles. */
  var STATUS = {
    NORMAL: 'normal',
    DISCREPANCY: 'discrepancy',
    INSUFFICIENT: 'insufficient'
  };

  /**
   * Threshold below which a difference is treated as measurement noise. API
   * accounting is integer-based and relays round differently, so exact zero is
   * not a realistic bar for "no discrepancy".
   */
  var DEFAULT_TOLERANCE_PERCENT = 1.0;

  function isFiniteNumber(v) {
    return typeof v === 'number' && isFinite(v);
  }

  function toNumberOrNull(v) {
    if (isFiniteNumber(v)) return v;
    if (typeof v === 'string' && v.trim() !== '') {
      var n = Number(v);
      if (isFiniteNumber(n)) return n;
    }
    return null;
  }

  /**
   * Token-layer difference.
   * @param {number|null} apiTokens      tokens the API reported
   * @param {number|null} accountTokens  tokens the platform deducted
   */
  function computeTokenDifference(apiTokens, accountTokens) {
    var api = toNumberOrNull(apiTokens);
    var account = toNumberOrNull(accountTokens);

    if (api === null || account === null) {
      return {
        status: STATUS.INSUFFICIENT,
        apiTokens: api,
        accountTokens: account,
        difference: null,
        absoluteDifference: null,
        discrepancyRate: null,
        reason: api === null ? 'missing_api_tokens' : 'missing_account_tokens'
      };
    }

    var difference = account - api;
    var absoluteDifference = Math.abs(difference);
    // Zero baseline has no defined rate; null beats Infinity.
    var discrepancyRate = api === 0 ? null : (absoluteDifference / api) * 100;

    return {
      status: STATUS.NORMAL,
      apiTokens: api,
      accountTokens: account,
      difference: difference,
      absoluteDifference: absoluteDifference,
      discrepancyRate: discrepancyRate,
      reason: 'ok'
    };
  }

  /**
   * Cost-layer difference, computed independently of the token layer.
   * theoreticalCost = what the published price list says; actualCost = what the
   * balance actually moved. Kept apart because relays may apply multipliers,
   * cache pricing or minimum billable units that per-token prices cannot express.
   */
  function computeCostDifference(theoreticalCost, actualCost) {
    var theory = toNumberOrNull(theoreticalCost);
    var actual = toNumberOrNull(actualCost);

    if (theory === null || actual === null) {
      return {
        status: STATUS.INSUFFICIENT,
        theoreticalCost: theory,
        actualCost: actual,
        difference: null,
        absoluteDifference: null,
        discrepancyRate: null,
        reason: theory === null ? 'missing_theoretical_cost' : 'missing_actual_cost'
      };
    }

    var difference = actual - theory;
    var absoluteDifference = Math.abs(difference);
    var discrepancyRate = theory === 0 ? null : (absoluteDifference / theory) * 100;

    return {
      status: STATUS.NORMAL,
      theoreticalCost: theory,
      actualCost: actual,
      difference: difference,
      absoluteDifference: absoluteDifference,
      discrepancyRate: discrepancyRate,
      reason: 'ok'
    };
  }

  /**
   * Turn a computed difference into a neutral verdict.
   * @returns {{status:string, conclusionKey:string, tolerancePercent:number}}
   */
  function classify(diff, tolerancePercent) {
    var tol = isFiniteNumber(tolerancePercent)
      ? tolerancePercent
      : DEFAULT_TOLERANCE_PERCENT;

    if (!diff || diff.status === STATUS.INSUFFICIENT) {
      return {
        status: STATUS.INSUFFICIENT,
        conclusionKey: 'result.insufficient',
        tolerancePercent: tol
      };
    }

    if (diff.discrepancyRate === null) {
      // No percentage could be formed (zero baseline); fall back to exactness.
      var exact = diff.absoluteDifference === 0;
      return {
        status: exact ? STATUS.NORMAL : STATUS.DISCREPANCY,
        conclusionKey: exact ? 'result.normal' : 'result.discrepancy',
        tolerancePercent: tol
      };
    }

    if (diff.discrepancyRate <= tol) {
      return {
        status: STATUS.NORMAL,
        conclusionKey: 'result.normal',
        tolerancePercent: tol
      };
    }

    return {
      status: STATUS.DISCREPANCY,
      conclusionKey: 'result.discrepancy',
      tolerancePercent: tol
    };
  }

  /**
   * Account usage from a balance delta.
   * Relays express quota in currency or in tokens; `unit` records which, so the
   * report never silently compares CNY against tokens.
   */
  function computeAccountUsage(before, after, unit) {
    var b = toNumberOrNull(before);
    var a = toNumberOrNull(after);
    if (b === null || a === null) {
      return { value: null, unit: unit || 'unknown', reason: 'missing_balance' };
    }
    // Balance normally falls; if it rose, report the signed delta honestly
    // instead of forcing an absolute value.
    return { value: b - a, unit: unit || 'unknown', reason: 'ok' };
  }

  /**
   * One-call verification used by the UI and the report builder.
   * @param {object} input {apiTokens, accountTokens, accountUnit,
   *                        theoreticalCost, actualCost, tolerancePercent}
   */
  function analyze(input) {
    var src = input || {};
    var tol = isFiniteNumber(src.tolerancePercent)
      ? src.tolerancePercent
      : DEFAULT_TOLERANCE_PERCENT;

    var tokenDiff = computeTokenDifference(src.apiTokens, src.accountTokens);
    var costDiff = computeCostDifference(src.theoreticalCost, src.actualCost);

    var tokenVerdict = classify(tokenDiff, tol);
    var costVerdict = classify(costDiff, tol);

    // The overall verdict is the weaker of the two available layers: a cost
    // discrepancy must not be hidden by a clean token layer, and vice versa.
    var layers = [];
    if (tokenDiff.status !== STATUS.INSUFFICIENT) layers.push(tokenVerdict.status);
    if (costDiff.status !== STATUS.INSUFFICIENT) layers.push(costVerdict.status);

    var overall;
    if (layers.length === 0) {
      overall = STATUS.INSUFFICIENT;
    } else if (layers.indexOf(STATUS.DISCREPANCY) >= 0) {
      overall = STATUS.DISCREPANCY;
    } else {
      overall = STATUS.NORMAL;
    }

    var conclusionKey =
      overall === STATUS.INSUFFICIENT
        ? 'result.insufficient'
        : overall === STATUS.DISCREPANCY
          ? 'result.discrepancy'
          : 'result.normal';

    return {
      status: overall,
      conclusionKey: conclusionKey,
      tolerancePercent: tol,
      token: { diff: tokenDiff, verdict: tokenVerdict },
      cost: { diff: costDiff, verdict: costVerdict },
      /**
       * What the UI needs to explain WHY a verdict was reached, so the user can
       * see the missing input instead of trusting a black box.
       */
      dataCompleteness: {
        apiTokens: tokenDiff.apiTokens !== null,
        accountTokens: tokenDiff.accountTokens !== null,
        theoreticalCost: costDiff.theoreticalCost !== null,
        actualCost: costDiff.actualCost !== null,
        unit: src.accountUnit || 'unknown'
      }
    };
  }

  return {
    STATUS: STATUS,
    DEFAULT_TOLERANCE_PERCENT: DEFAULT_TOLERANCE_PERCENT,
    computeTokenDifference: computeTokenDifference,
    computeCostDifference: computeCostDifference,
    computeAccountUsage: computeAccountUsage,
    classify: classify,
    analyze: analyze
  };
});
