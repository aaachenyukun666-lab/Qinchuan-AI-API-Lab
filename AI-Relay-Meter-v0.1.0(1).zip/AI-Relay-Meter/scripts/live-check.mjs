#!/usr/bin/env node
/**
 * AI Relay Meter - live acceptance smoke check
 *
 * Runs a small batch of REAL requests against an OpenAI-compatible API and
 * prints what actually happened. This is the "have I really verified this
 * against a live provider" script referenced in the acceptance criteria.
 *
 * Usage (all optional; omitted variables degrade gracefully):
 *   ARM_BASE_URL=https://api.deepseek.com/v1 \
 *   ARM_API_KEY=sk-... \
 *   ARM_MODEL=deepseek-chat \
 *   node scripts/live-check.mjs
 *
 * No key = no network requests. The script reports "skipped" honestly instead
 * of fabricating a pass. Nothing here uploads your key anywhere; it is used
 * only for the requests you explicitly start here.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const engine = require(join(root, 'src/js/engine.js'));
const api = require(join(root, 'src/js/api.js'));
const report = require(join(root, 'src/js/report.js'));
const mask = require(join(root, 'src/js/core/mask.js'));

const BASE = process.env.ARM_BASE_URL || '';
const KEY = process.env.ARM_API_KEY || '';
const MODEL = process.env.ARM_MODEL || '';

function h1(t) { console.log('\n' + t + '\n' + '='.repeat(t.length)); }

if (!BASE || !KEY) {
  h1('Live check skipped');
  console.log('ARM_BASE_URL and ARM_API_KEY are not both set.');
  console.log('No network requests were made and no result was simulated.');
  console.log('Run with:');
  console.log('  ARM_BASE_URL=https://api.deepseek.com/v1 ARM_API_KEY=sk-... ARM_MODEL=deepseek-chat node scripts/live-check.mjs');
  process.exit(0);
}

console.log('Base URL :', BASE);
console.log('Model    :', MODEL || '(auto-detected)');
console.log('API Key  :', mask.maskKey(KEY));

let model = MODEL.trim();

try {
  // 1. Model discovery (non-fatal when unsupported).
  h1('1. Model discovery');
  try {
    const r = await api.listModels({ baseUrl: BASE, apiKey: KEY, timeoutMs: 15000 });
    console.log('models endpoint: OK,', r.models.length, 'model(s)');
    if (!model && r.models.length) {
      model = r.models[0].id;
      console.log('  using first model:', model);
    }
  } catch (e) {
    console.log('models endpoint:', e.code || 'error', '-', e.apiMessage || e.message || '');
    console.log('  (this is normal for relays without a /models endpoint)');
  }

  if (!model) {
    console.log('No model available; set ARM_MODEL to continue.');
    process.exit(2);
  }

  // 2. One conservative real request.
  h1('2. Real request');
  const out = await engine.run({
    baseUrl: BASE, apiKey: KEY, model,
    requests: 1, maxTokens: 32, concurrency: 1, timeoutMs: 60000,
    prompt: 'Reply with one short sentence.', mode: 'usage'
  }, {
    onRecord: (r) => {
      const u = r.hasUsage
        ? `prompt=${r.promptTokens} completion=${r.completionTokens} total=${r.totalTokens}`
        : 'NO usage returned';
      console.log(`  HTTP ${r.status} · ${r.latencyMs} ms · ${u}`);
    }
  });

  const summary = out.summary;
  console.log('  complete:', summary.dataComplete, '| totalTokens:', summary.totalTokens);

  // 3. Balance probe (non-fatal).
  h1('3. Balance probe');
  try {
    const b = await api.probeBalance({ baseUrl: BASE, apiKey: KEY });
    console.log(b.available
      ? `  balance: ${b.amount} ${b.currency || ''} (source: ${b.source})`
      : '  no balance endpoint detected (normal for many relays)');
  } catch (e) {
    console.log('  balance probe failed:', e.code || e.message || '');
  }

  // 4. Report round-trip.
  h1('4. Report');
  const rep = report.build(out, { locale: 'en-US', tolerancePercent: 1 });
  const json = report.toJSON(rep);
  report.assertNoSecrets(json);
  console.log('  JSON export:', json.length, 'bytes | no key material:', !json.includes(KEY));
  console.log('  filename:', report.suggestFilename(rep, 'json'));

  h1('Result');
  if (summary.dataComplete) {
    console.log('PASS: the relay returned Token Usage for a real request.');
    process.exit(0);
  } else {
    console.log('INCOMPLETE: requests ran but usage was not reported for all of them.');
    console.log('This is a real, honest outcome — not a fabricated pass.');
    process.exit(3);
  }
} catch (e) {
  console.error('\nLive check errored:', e && e.code ? e.code : e.message);
  process.exit(4);
}
